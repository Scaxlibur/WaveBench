# 归档：重构前的 WaveBench 可执行仪器插件 API 约定

> [!NOTE]
> 本页保留文档重构前的 API 汇编，包含可能漂移的签名、capability、开发线和型号材料。当前插件模型见[插件 Reference](../reference/plugins/index.md)，精确公开 API 以源码中的 Protocol、model 和 validator 为准。

本文定义 `wavebench.instrument.v2` 的包结构、descriptor、factory、capability 和运行时边界。开发流程见[插件开发](../development/plugin-development.md)，安装与事务边界见[管理仪器插件](../how-to/manage-plugins.md)。

文中的约束分为三类：

- 「核心强制」：当前 WaveBench 会在包检查、descriptor 加载或 driver 创建时拒绝不符合要求的插件。
- 「接口约定」：插件必须遵守，但 Python 运行时无法完整验证；插件测试负责兜底。
- 「建议」：用于降低兼容和维护风险，不作为当前加载门槛。

## 适用范围

WaveBench 有两套不同的 entry point：

| entry point | API | 作用 | 是否提供仪器执行能力 |
| --- | --- | --- | --- |
| `wavebench.drivers` | `wavebench.instrument.v1` | 只读 metadata | 否 |
| `wavebench.instruments` | `wavebench.instrument.v2` | descriptor、factory 和 driver | 是 |

V2 capability 只声明 driver 已实现的能力。它不会自动生成 CLI 命令、Service 或 run-plan step；核心没有对应消费路径时，声明 capability 也不会让该功能自动出现。

V2 插件是可信 Python 代码，不是沙箱。导入 descriptor、构建源码 wheel 和安装包都可能执行插件代码。只应处理来源、版本和哈希均已确认的插件包。

## 包和 entry point

受管插件包必须满足以下条件：

| 项目 | 要求 | 校验位置 |
| --- | --- | --- |
| 分发 | 一个纯 Python wheel | 包检查 |
| Python 版本 | `Requires-Python` 如有声明，必须包含当前解释器版本 | 包检查 |
| WaveBench 依赖 | 必须恰好有一个当前环境中生效的 `wavebench` 依赖，并包含当前版本 | 包检查 |
| entry point 数量 | 必须恰好有一个 `wavebench.instruments` entry point | 包检查 |
| entry point 名 | 非空、无首尾空白、内部无空白 | 包检查 |
| entry point 目标 | 使用 `module:object` 形式 | 包检查 |
| driver 身份 | entry point 名必须与 descriptor 的 `driver_id` 完全一致 | 安装后检查和运行时 registry |

最小 `pyproject.toml`：

```toml
[build-system]
requires = ["hatchling>=1.25"]
build-backend = "hatchling.build"

[project]
name = "wavebench-example-scope"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = ["wavebench>=0.8,<0.9"]

[project.entry-points."wavebench.instruments"]
"example.scope" = "wavebench_example_scope:descriptor"
```

entry point 可以直接导出 `InstrumentDescriptor`，也可以导出返回 `InstrumentDescriptor` 的无参同步函数。其他返回类型会被拒绝。

descriptor 模块导入时不得连接仪器、调用 `open_transport()`、发送命令、扫描端口、创建文件或修改进程级全局状态。这是接口约定，当前加载器不会尝试撤销导入副作用。

## 导入边界

插件应从 `wavebench.instruments` 使用公开 descriptor、Protocol 和 model，从 `wavebench.errors` 使用公共异常类型：

```python
from wavebench.errors import DataError, InstrumentError
from wavebench.instruments import InstrumentDescriptor, OptionSpec, WaveformData
```

`wavebench.instruments.__all__` 是当前公开名称清单。插件不应依赖以下实现模块：

- `wavebench.instruments.registry` 和 `wavebench.instruments.factory`；
- `wavebench.services`、`wavebench.cli`、`wavebench.config` 和 `wavebench.tui`；
- 内置 driver、受管安装账本或私有辅助函数。

Protocol 使用结构化接口。driver 不必继承 Protocol；方法名、参数、返回类型和行为符合约定即可。

## Descriptor

最小 descriptor：

```python
from wavebench.instruments import InstrumentDescriptor, OptionSpec


def _open_driver(context):
    from .driver import ExampleScope

    return ExampleScope(
        transport=context.open_transport(),
        check_errors=bool(context.settings["check_errors"]),
        block_points=int(context.options["block_points"]),
    )


def descriptor() -> InstrumentDescriptor:
    return InstrumentDescriptor(
        driver_id="example.scope",
        kind="scope",
        display_name="Example Scope",
        manufacturer="Example",
        models=("EX1",),
        aliases=(),
        capabilities=("scope.idn", "scope.capture_waveform"),
        idn_patterns=("EXAMPLE,EX1",),
        backends=("pyvisa",),
        resource_schemes=("tcpip",),
        option_specs=(
            OptionSpec("block_points", int, default=250_000, minimum=1),
        ),
        permissions=("instrument.io", "configured-resource-only"),
        factory=_open_driver,
        summary="Example oscilloscope driver.",
        wavebench_min_version="0.8.0",
        wavebench_max_version="0.9.0",
        scope_coupling_policy="unknown",
    )
```

### 字段约定

| 字段 | 核心强制 | 接口约定和用途 |
| --- | --- | --- |
| `driver_id` | 非空、无首尾空白；外置插件必须与 entry point 名一致 | 使用小写 ASCII canonical ID，推荐 `vendor.model` 形式；发布后不得复用给其他设备族 |
| `kind` | 配置解析时必须与目标槽位一致 | 只能是 `scope`、`source`、`rf_source`、`power`、`dmm` 或 `sweep_analyzer` |
| `display_name` | 仅要求构造参数存在 | 面向用户的简短名称，不承担型号匹配 |
| `manufacturer` | 仅要求构造参数存在 | 使用厂商正式名称 |
| `models` | 至少包含一项 | 每项应为非空型号名称；不要把营销系列名当作已验证型号 |
| `aliases` | 外置 V2 插件必须为空 | alias 由核心维护，插件只能使用 canonical ID |
| `capabilities` | 非空；每项必须出现在核心 capability 表中 | 每项必须以当前 `kind` 为前缀，只声明已经实现并测试的能力 |
| `idn_patterns` | 当前不校验内容 | `doctor` 会删除非字母数字字符后做不区分大小写的子串匹配；它不是正则表达式，也不是设备身份认证 |
| `backends` | 至少包含一项 | 只使用核心支持的 backend token，见下文「Transport 选择」 |
| `resource_schemes` | 必须是去重的小写 token；空 tuple 表示不限制 | LAN-only 插件通常声明 `("tcpip",)`；该字段只检查 resource 前缀，不探测设备 |
| `option_specs` | 配置值按 `OptionSpec` 校验 | 名称必须唯一并使用小写 snake_case；当前核心不自动检查名称重复 |
| `permissions` | 当前只展示，不参与授权判断 | 常规仪器插件声明 `instrument.io` 和 `configured-resource-only`；不得把该字段描述成沙箱权限 |
| `factory` | 必须可调用 | 接收一个 `DriverContext`，同步返回 driver 对象 |
| `summary` | 当前不校验 | 一句话说明设备族和已实现范围 |
| `api_version` | 必须精确等于 `wavebench.instrument.v2` | 不按语义版本范围匹配；通常保留默认值 |
| `wavebench_min_version` | 当前核心版本不得低于该值 | 与 `wavebench_max_version` 组成半开区间 |
| `wavebench_max_version` | 当前核心版本必须低于该值 | `0.8.x` 插件通常使用 `0.9.0` |
| `distribution`、`version`、`source`、`origin` | entry point 加载后由 registry 按已安装分发覆盖 | 不得用于插件内部授权、信任或功能分支 |
| `scope_coupling_policy` | 值由类型约定为三种策略 | scope 必须准确声明；无法证明时使用 `unknown`，核心会默认拒绝无法确认高阻的采集 |
| `config_fields` | 当前只展示；为空时由 `option_specs` 推导 `options.<name>` | 只列出用户实际可配置的字段，不代表核心会按此字段授权 |
| `scope_extensions` | 仅允许 scope descriptor 使用，类型必须为 `ScopeDescriptorExtensions` | 为 R1.3 capability 提供静态截图、采集控制、trace、标准 waveform bounded profile 和 average capture V2 profile；旧插件保持 `None` |
| `source_extensions` | 仅允许 source descriptor 使用，类型必须为 `SourceDescriptorExtensions` | 为 `source.snapshot_v2` 及各已声明的 Source V2 写 capability 提供 topology、feature profile 和查询合同；旧插件保持 `None` |
| `rf_source_extensions` | `rf_source` descriptor 必须提供，且其它 kind 不得提供；类型必须为 `RfSourceDescriptorExtensions` | M0 的独立 RF topology、feature 和 protection policy；该字段 append-only，旧插件保持 `None` |

### `scope_coupling_policy`

| 值 | 语义 |
| --- | --- |
| `fixed-high-impedance` | 仪器的 `AC`、`DC`、`GND` 等 coupling 不切换到低阻终端 |
| `switchable-termination` | coupling 可能代表高阻或 50 Ω；核心按查询值和显式放行判断 |
| `unknown` | 无法证明输入阻抗语义；默认 fail closed |

## `OptionSpec`

`OptionSpec` 只处理一层标量配置，不是通用 schema 系统。

| 字段 | 语义 |
| --- | --- |
| `name` | `[<kind>.options]` 下的键名 |
| `value_type` | 使用 `isinstance(value, value_type)` 做运行时检查 |
| `default` | 非 `None` 时，在配置缺失后写入 `context.options`，并执行同样的校验 |
| `required` | 为 `True` 且配置缺失时拒绝创建 driver |
| `minimum`、`maximum` | 将值转换为 `float` 后检查闭区间边界 |
| `choices` | 使用 Python 相等比较检查允许值 |

校验顺序如下：

1. 拒绝所有未在 `option_specs` 中声明的键。
2. 校验显式配置值。
3. 对缺失的 required option 报错。
4. 对其余缺失项应用非 `None` 默认值。

插件还必须遵守以下约定：

- `OptionSpec.name` 不得重复；当前实现会按名称建立映射，但不会主动报告重复项。
- 不要同时设置 `required=True` 和非 `None` 默认值；缺失时 required 检查优先。
- `default=None` 表示「不向 `context.options` 写入该键」，不能表示显式传入 `None`。
- `minimum` 和 `maximum` 只用于可安全转换为浮点数的数值类型。
- 容器、联合类型和字段间约束应使用公共 model 或在 factory/driver 中显式检查。

## `DriverContext`

`DriverContext` 是 frozen dataclass。`settings` 和 `options` 会复制为只读 mapping；只读是浅层的，插件不应在其中存放或修改可变对象。

| 属性 | 语义 |
| --- | --- |
| `driver_id` | 已解析的 canonical ID |
| `kind` | 已验证的仪器类型 |
| `resource` | 配置中的单个 resource 原值 |
| `backend` | 核心完成 alias 和优先级选择后的 backend token |
| `timeout_ms` | 普通连接和查询超时 |
| `opc_timeout_ms` | OPC 等待超时 |
| `logger` | 当前操作的 `CommandLogger` |
| `settings` | 核心设置；当前 scope、source 和 power 提供 `check_errors`，DMM 不保证该键存在 |
| `options` | 经过 `OptionSpec` 校验并补齐默认值的插件选项 |
| `open_transport()` | 打开核心配置和记录的 transport |

插件不得读取完整 `WaveBenchConfig`，也不得从环境变量或私有配置文件另选 resource。resource、backend、timeout 和日志必须由核心传入。

一次 driver 创建期间最多允许一个 transport 成功打开。第二次调用 `open_transport()` 会抛出 `ConfigError`。当前实现允许 factory 不打开 transport，但真实仪器 driver 应在 factory 中打开并接管唯一 transport，不应保存整个 context 供后台延迟建连。

## Transport 选择

当前核心可以创建以下 backend：

| token | transport |
| --- | --- |
| `serial` | `SerialTransport` |
| `pyvisa` | `PyVisaTransport` |
| `rsinstrument` | `RsInstrumentTransport` 的兼容选择路径 |
| `rsinstrument-socket` | RsInstrument SocketIO |
| `rsinstrument-rsvisa` | RsVisa |
| `rsinstrument-pyvisa-py` | pyvisa-py |

`lan`、`visa` 和 `pyvisa` 配置通常归一化为 `pyvisa`。当 descriptor 的全部 backend 都属于 RsInstrument 家族且配置为 `lan` 时，核心选择 descriptor 中的第一项。因此，RsInstrument backend 的顺序具有运行时意义。

`resource_schemes` 非空时，核心提取 resource 开头连续的 ASCII 字母并转为小写后匹配。例如 `TCPIP0::...` 的 scheme 为 `tcpip`。路径形式的串口 resource 不以字母开头，通常不应配合非空 `resource_schemes`。

插件不得自行绕过 `context.open_transport()` 创建 PyVISA、串口或 socket 会话，也不得在部分读取、写入或触发失败后静默切换 backend 并重放操作。

## Factory 和资源所有权

factory 的调用顺序为：

1. 核心解析 descriptor，并检查 API 版本、kind、WaveBench 兼容区间和 capability 名。
2. 核心选择 backend，检查 resource scheme，并校验 options。
3. 核心构造 `DriverContext` 并调用 factory。
4. 核心检查 `close()`，以及每个已声明 capability 对应的方法是否可调用。
5. Service 使用 driver；one-shot 调用或 run session 结束时调用 `close()`。

factory 返回 driver 后，transport 的所有权转移给 driver。`close()` 必须释放 transport 和插件创建的后台资源；建议实现为幂等操作。若 factory 或 capability 检查失败，核心优先调用已返回 driver 的 `close()`；只有 `close()` 不存在或失败时，核心才直接关闭已记录的 transport。

factory 必须同步返回，不得返回 coroutine、context manager 或 `(driver, transport)` tuple。factory 也不得启动无法由 `close()` 停止的线程或子进程。

当 `scope_extensions.waveform_binary_profile` 或 `average_capture_profile_v2` 非空时，`open_transport()` 返回的
guard 在 factory 返回、profile、Protocol 和 backend/resource 校验完成前拒绝全部仪器 I/O，并返回发送前错误
`factory_construction_pending`。factory 必须把初始化中的仪器查询移到后续 Service 操作；验证失败时核心关闭
已经打开的 transport。该门禁只覆盖 `DriverContext.open_transport()` 返回的 guard，不把可信 Python 插件当作沙箱。

## Capability 契约

核心在执行操作前检查所需 capability，缺失时不会打开 transport。driver 创建后，核心只检查对应属性是否可调用，不检查参数签名、返回类型、异常类型或操作语义。这些内容由 Protocol、model 和插件测试保证。

capability 必须与 descriptor 的 `kind` 使用相同前缀。当前 V2 loader 会拒绝未知 capability，但不会单独拒绝「已知但前缀属于其他 kind」的组合；插件测试必须覆盖该项。

旧接口的方法签名以 [`contracts.py`](../../src/wavebench/instruments/contracts.py) 为准，返回
对象以 [`models.py`](../../src/wavebench/instruments/models.py) 为准。Scope R1.3 的 Protocol
和 model 由 [`scope_extensions.py`](../../src/wavebench/instruments/scope_extensions.py) 定义，
并从 `wavebench.instruments` 导出。当前 capability 到方法的映射如下。

### Scope

| capability | 必须可调用的方法 |
| --- | --- |
| `scope.idn` | `idn` |
| `scope.errors` | `errors` |
| `scope.autoscale` | `autoscale` |
| `scope.fetch_waveform` | profile 为 `None` 时为 `fetch_waveform`；有 `waveform_binary_profile` 时为 `fetch_waveform_bounded` 和 waveform transfer recovery 方法 |
| `scope.capture_waveform` | profile 为 `None` 时为 `capture_waveform`；有 `waveform_binary_profile` 时为 `capture_waveform_bounded` 和 waveform transfer recovery 方法 |
| `scope.capture_waveforms` | profile 为 `None` 时为 `capture_waveforms`；有 `waveform_binary_profile` 时为 `capture_waveforms_bounded` 和 waveform transfer recovery 方法 |
| `scope.screenshot` | `screenshot_png` |
| `scope.channel_coupling` | `channel_coupling` |
| `scope.channel_input_state_v2` | `get_channel_input_state_v2` |
| `scope.digital_status_v2` | `get_digital_status_v2` |
| `scope.snapshot` | `get_snapshot` |
| `scope.acquisition_status` | `get_acquisition_status` |
| `scope.capture_average` | `capture_average` |
| `scope.capture_average_v2` | `snapshot_average_capture_state`、`set_average_acquisition_type_v2`、`get_average_configuration_v2`、`set_average_count_v2`、`acquire_average_single_v2`、`get_device_average_complete_v2`、`fetch_average_waveform_bounded`、`restore_average_capture_state`、`verify_average_capture_state_restored` |
| `scope.digital_status` | `get_digital_status` |
| `scope.digital_waveform` | `get_digital_waveform` |
| `scope.history_timestamps` | `get_history_timestamps` |
| `scope.measurement_statistics` | `get_measurement_statistics` |
| `scope.math_metadata` | `get_math_waveform_metadata` |
| `scope.fft_status` | `get_fft_status` |
| `scope.reference_metadata` | `get_reference_waveform_metadata` |
| `scope.cursor_readout` | `get_cursor_readout` |
| `scope.screenshot_profile` | `get_screenshot_profile` |
| `scope.screenshot_v2` | `get_screenshot_profile`、`capture_screenshot`、`snapshot_screenshot_state`、`restore_screenshot_state`、`verify_screenshot_state_restored` |
| `scope.acquisition_run_state` | `get_acquisition_run_state` |
| `scope.acquisition_control` | `get_acquisition_run_state`、`start_continuous`、`stop_acquisition`、`acquire_single`、`snapshot_acquisition_control`、`restore_acquisition_control`、`verify_acquisition_control_restored` |
| `scope.trace_metadata` | `get_trace_metadata` |
| `scope.fetch_trace` | `get_trace_metadata`、`fetch_trace`、`snapshot_trace_transfer_state`、`restore_trace_transfer_state`、`verify_trace_transfer_state_restored` |
| `scope.error_drain_v1` | `drain_errors` |

`scope.capture_waveforms` 的固定语义是：先配置全部目标通道，只执行一次 acquisition 和 OPC 等待，再逐通道读取。不得静默退回逐通道重复触发。回调、失败时部分结果和返回字典的签名以 `MultiChannelScopeDriver` 为准。

### 标准 waveform bounded profile

`ScopeWaveformBinaryProfile` 是 `wavebench.instrument.v2` 的 additive descriptor extension，不新增
capability。profile 为 `None` 时，三个标准 waveform capability 保持原有方法签名和调用顺序；profile
非空时，operations 必须与声明的 `scope.fetch_waveform`、`scope.capture_waveform`、
`scope.capture_waveforms` 精确对应。

每个 `ScopeWaveformBinaryOperationProfile` 声明 response、operation-total、query-count、
resynchronization 预算，以及 transfer-state 的 snapshot、restore、verify 步数和字段顺序。首版只接受
IEEE definite block；`transport_trailing_hex` 是最多 16 bytes 的小写偶数字符十六进制序列，空字符串表示
已验证的空 trailing，不表示忽略 trailing。

核心上限为单响应 8 MiB、单操作 64 MiB、256 次 binary query 和 64 KiB resynchronization。profile
只能收紧这些值。标准 bounded waveform 只接受核心 PyVISA 或 RsInstrument 的可证明 VISA `INSTR` 读取路径；
Serial、SocketIO 和第三方 duck transport 即使存在 `query_binary()` 也不会被视为已支持。

bounded driver 必须实现 `ScopeWaveformTransferRecoveryDriver`，以及对应的
`ScopeBoundedWaveformFetchDriver`、`ScopeBoundedWaveformCaptureDriver` 或
`ScopeBoundedMultiWaveformCaptureDriver`。`ScopeWaveformTransfer*` 是独立于已发布
`ScopeTraceTransfer*` 的恢复模型；capture profile 必须覆盖采集、触发、时基、通道和 waveform
transfer 的完整恢复闭包。主读取必须使用受 core ledger 授权的
`query_binary(..., framing=DEFINITE_BLOCK, replay=NO_REPLAY)`；不得调用 `query_bin_block()`、自行传递
trailing/resynchronization 参数、重放或继续已发送的 binary query。
core 会把 descriptor 的 framing 绑定到 ledger；请求 `MESSAGE` 或其他不匹配 framing 时会在发送前拒绝。

标准 `ScopeConfig.check_errors=true` 在 bounded 路径固定要求 `scope.error_drain_v1`；`false` 固定禁用
typed drain。核心不使用 `scope.errors` 代替 typed drain。多通道 bounded 方法必须保留
`on_channel_start` 和 `on_waveform` 的既有回调与部分结果语义。

### Average capture V2 profile

`scope.capture_average_v2` 是独立 capability，不替换 `scope.capture_average`，也不使用
`ScopeWaveformBinaryProfile`、标准 waveform capability 或 `ScopeWaveformTransfer*` 恢复类型。
它只接受一个 channel、`global_acquisition` 和 `device_average_complete` 完成证据。descriptor 必须追加
`scope_extensions.average_capture_profile_v2`，并同时声明：

- `scope.idn`、`scope.acquisition_status_v2`、`scope.acquisition_run_state`、`scope.acquisition_control` 和
  `scope.channel_input_state_v2`；
- `ScopeAverageCaptureDriverV2` 的全部方法，以及 V2 输入状态和 run-state 方法；
- 只收紧核心上限的 `ScopeAverageCaptureBinaryProfile`：单响应 8 MiB、单操作 64 MiB、256 次 query 和
  64 KiB resynchronization；首版固定 `DEFINITE_BLOCK` 和精确 trailing；
- 包含 run state、acquisition、trigger、timebase、channel 和 waveform transfer 的完整 restore order，以及
  snapshot、main、restore、verify step 上限。

核心执行固定顺序：identity、输入终端和停止状态 preflight，error-before，type write/readback，count
write/readback，停止状态复核，single completion，新鲜 `device_average_complete=True`，一次受 ledger 授权的
`query_binary()`，error-after，restore 与 fresh verify。每次 setter 后必须立即返回完整 configuration readback；
成功和已证明同步的数据失败都恢复，失步后 session 进入 `poisoned` 且不再发送 cleanup I/O。

`ScopeConfig.check_errors=true` 固定要求 `scope.error_drain_v1`，并使用 before-and-after typed drain；`false`
固定禁用 drain。不得调用 legacy `capture_average()`、`query_bin_block()`，也不得将 STOP、OPC、count 变化或
可读 waveform 当成平均完成证明。核心没有为该 V2 operation 增加 CLI、run-plan step、capture package writer 或
artifact schema。

### Scope R1.3 扩展

R1.3 的 Protocol 和 model 从 `wavebench.instruments` 导出。声明任一新增 capability 时，wheel
依赖和 descriptor 的 `wavebench_min_version` 都必须为 `0.8.23` 或更高的 `0.8.x` 版本。
`waveform_binary_profile` 与 bounded waveform Protocol 首次提供于核心 `0.8.24`，因此采用它们的
插件必须把 wheel 依赖和 descriptor 下限同时提高到 `0.8.24` 或更高的 `0.8.x` 版本。
`average_capture_profile_v2` 与 `scope.capture_average_v2` 也使用 `0.8.24` 开发线静态下限，但同样必须等待
第一个实际包含完整合同的正式发行版本，才能修改 wheel 依赖、descriptor 版本门或 capability 声明。

上述 `0.8.23`／`0.8.24` 是核心开发线的静态合同下限，不是外部插件的发布授权。正式发行物尚未
包含对应合同前，插件可以针对开发树做离线 conformance，但不得据此发布提高后的
`Requires-Dist`、`wavebench_min_version` 或新增 capability。核心发布后，应把两处版本门同时改为
第一个实际包含完整合同的发行版本；若同一版本号已有不含合同的 artifact，必须使用可区分的更高版本。

profile 依赖如下：

| capability | 必需 descriptor profile |
| --- | --- |
| `scope.screenshot_profile`、`scope.screenshot_v2` | `scope_extensions.screenshot_profile` |
| `scope.acquisition_control` | `scope_extensions.acquisition_control_profile` |
| `scope.trace_metadata`、`scope.fetch_trace` | `scope_extensions.trace_profile` |
| `scope.capture_average_v2` | `scope_extensions.average_capture_profile_v2` |

`scope.acquisition_control` 还必须同时声明 `scope.acquisition_run_state`。缺少 profile、方法或核心
版本门时，核心会拒绝 descriptor；只实现方法而不声明 capability，不会产生隐式能力。

`scope.channel_input_state_v2` 是 scope 可移植性 V2 的只读 capability，不需要 descriptor profile。
它要求 `ScopeChannelInputStateV2` 的 coupling、termination、`impedance_ohm` 与
`unavailable_fields` 符合公共模型，并在 factory 内启用 construction barrier。它不设置输入终端，
不替代旧 `scope.channel_coupling`，也不让标准 fetch/capture 改走 V2 安全门。当前开发线的静态
下限为 `0.8.24`；正式发行前不得由插件提高 wheel 或 descriptor 版本门、声明该 capability。

`scope.digital_status_v2` 同样是无 profile 的只读 capability。它要求
`ScopeDigitalChannelStatusV2` 精确表达逐通道、POD 和 shared 状态，使用 `"unknown"` 保留已查询的
未知 token，并以 `unavailable_fields` 解释每个缺席值。它不产生 `scope.digital_waveform`，不读取
waveform payload，也不改变旧 `scope.digital_status`。当前开发线的静态下限为 `0.8.24`；正式发行前
不得由插件提高 wheel 或 descriptor 版本门、声明该 capability。

公共调用入口为 `ScopeService` 和以下 CLI：

```text
wavebench scope screenshot profile
wavebench scope screenshot capture
wavebench scope acquisition status|start|single|stop
wavebench scope trace metadata|fetch
```

旧 `scope capture --screenshot` 继续服务声明 `scope.screenshot` 的插件。插件同时声明旧能力
和 `scope.screenshot_v2` 时，旧命令仍走 legacy 路径；只有 v2、没有旧能力时，核心会在仪器
I/O 前拒绝嵌入请求。需要 v2 截图时使用独立的 `scope screenshot capture`。父 capture 字段
闭包在后续实现前不得由插件自行模拟。

### Source

| capability | 必须可调用的方法 |
| --- | --- |
| `source.idn` | `idn` |
| `source.errors` | `errors`、`assert_no_errors` |
| `source.status` | `get_status` |
| `source.channel_profile` | `get_channel_profile` |
| `source.coupling_profile` | `get_coupling_profile` |
| `source.coupling_configure` | `configure_coupling` |
| `source.harmonic_profile` | `get_harmonic_profile` |
| `source.harmonic_configure` | `configure_harmonics` |
| `source.modulation_am_profile` | `get_am_modulation_profile` |
| `source.modulation_am_configure` | `configure_am_modulation` |
| `source.modulation_fm_profile` | `get_fm_modulation_profile` |
| `source.modulation_fm_configure` | `configure_fm_modulation` |
| `source.modulation_pm_profile` | `get_pm_modulation_profile` |
| `source.modulation_pm_configure` | `configure_pm_modulation` |
| `source.modulation_pwm_profile` | `get_pwm_modulation_profile` |
| `source.modulation_pwm_configure` | `configure_pwm_modulation` |
| `source.pulse_profile` | `get_pulse_profile` |
| `source.pulse_configure` | `configure_pulse` |
| `source.burst_profile` | `get_burst_profile` |
| `source.burst_configure` | `configure_burst` |
| `source.burst_trigger` | `trigger_burst` |
| `source.sweep_profile` | `get_sweep_profile` |
| `source.sweep_configure` | `configure_sweep` |
| `source.sweep_trigger` | `trigger_sweep` |
| `source.counter_profile` | `get_counter_profile` |
| `source.set_frequency` | `set_frequency` |
| `source.set_function` | `set_function` |
| `source.set_amplitude_vpp` | `set_amplitude_vpp` |
| `source.set_square_duty_cycle` | `set_square_duty_cycle` |
| `source.output` | `set_output` |
| `source.arbitrary_probe` | `probe_arbitrary_queries` |
| `source.arbitrary_upload` | `upload_dg4000_dac14_block` |
| `source.snapshot_v2` | `execute_source_query_plan_v2` |
| `source.basic_configure_v2` | `configure_source_basic_v2` |
| `source.basic_live_configure_v2` | `configure_source_basic_live_v2` |
| `source.output_v2` | `set_source_output_v2` |
| `source.counter_configure_v2` | `configure_source_counter_v2` |
| `source.counter_enable_v2` | `set_source_counter_enabled_v2` |
| `source.counter_measure_v2` | `measure_source_counter_v2` |
| `source.harmonics_configure_v2` | `configure_source_harmonics_v2` |
| `source.harmonics_disable_v2` | `disable_source_harmonics_v2` |
| `source.modulation_configure_v2` | `configure_source_modulation_v2` |
| `source.modulation_pm_configure_v2` | `configure_source_pm_modulation_v2` |
| `source.modulation_fm_configure_v2` | `configure_source_fm_modulation_v2` |
| `source.modulation_pwm_configure_v2` | `configure_source_pwm_modulation_v2` |
| `source.sweep_configure_v2` | `configure_source_sweep_v2` |
| `source.burst_configure_v2` | `configure_source_burst_v2` |
| `source.pulse_configure_v2` | `configure_source_pulse_v2` |
| `source.arbitrary_storage_v2` | `read_source_arbitrary_storage_v2`、`mutate_source_arbitrary_storage_v2` |
| `source.arbitrary_select_v2` | `select_source_arbitrary_v2` |
| `source.combine_configure_v2` | `configure_source_combine_v2` |
| `source.coupling_configure_v2` | `configure_source_coupling_v2` |
| `source.tracking_configure_v2` | `configure_source_tracking_v2` |
| `source.phase_relation_configure_v2` | `configure_source_phase_relation_v2` |

### Source V2 扩展

`source.snapshot_v2`、`source.basic_configure_v2`、`source.basic_live_configure_v2`、`source.output_v2`、
`source.counter_configure_v2`、`source.counter_enable_v2`、`source.counter_measure_v2`、
`source.harmonics_configure_v2`、`source.harmonics_disable_v2`、`source.modulation_configure_v2`、`source.modulation_pm_configure_v2`、`source.modulation_fm_configure_v2`、`source.modulation_pwm_configure_v2`、`source.sweep_configure_v2`、`source.burst_configure_v2`、`source.pulse_configure_v2`、`source.arbitrary_storage_v2`、`source.arbitrary_select_v2`、`source.combine_configure_v2`、`source.coupling_configure_v2`、`source.tracking_configure_v2` 和 `source.phase_relation_configure_v2` 从核心 `0.8.24` 开始提供，仍使用
`wavebench.instrument.v2`。采用任一 Source V2 capability 的
wheel 依赖和 descriptor `wavebench_min_version` 都必须为 `0.8.24` 或更高的 `0.8.x` 版本。
`source_extensions` 位于 descriptor 末尾且默认值为 `None`，因此未声明该能力的 V1 插件不需要
修改 descriptor 或提高版本下限。

插件从 `wavebench.instruments` 导入 `SourceDescriptorExtensions`、`SourceSnapshotV2Driver`、
`SourceBasicConfigureV2Driver`、`SourceBasicLiveConfigureV2Driver`、`SourceOutputV2Driver`、
`SourceCounterConfigureV2Driver`、`SourceCounterEnableV2Driver`、`SourceCounterMeasureV2Driver`、`SourceHarmonicConfigureV2Driver`、`SourceHarmonicDisableV2Driver`、
`SourceModulationConfigureV2Driver`、`SourcePmModulationConfigureV2Driver`、`SourceFmModulationConfigureV2Driver`、`SourcePwmModulationConfigureV2Driver`、`SourceSweepConfigureV2Driver`、`SourceBurstConfigureV2Driver`、`SourcePulseConfigureV2Driver`、`SourceArbitraryStorageV2Driver`、`SourceArbitrarySelectV2Driver`、`SourceCombineConfigureV2Driver`、`SourceCouplingConfigureV2Driver`、`SourceTrackingConfigureV2Driver`、`SourcePhaseRelationConfigureV2Driver`、query
plan／execution record 和各类 typed profile。核心签发 semantic query plan；snapshot driver 只负责将
item 转成合法的厂商协议查询并返回类型化执行记录。插件不得返回完整 `SourceSnapshotV2`，也不得自行判定 `UNSUPPORTED`、
`NOT_APPLICABLE`、runtime profile 或 snapshot consistency。

snapshot query contract 只接受 `PURE_READ`。每个受支持的 read feature 必须有同 scope 的 query contract；
identity 必须是唯一、required 的 instrument-scope facet。声明为 `UNSUPPORTED` 或 `UNKNOWN` 的
feature 不得进入查询计划。查询项、effect、字段覆盖、query count 和 deadline 由核心复核；不符合
合同的执行记录不会生成 snapshot。

只读公共调用入口为 `SourceService.snapshot_v2()` 和：

```text
wavebench source snapshot-v2
```

基础写入入口由核心提供，不由插件拼接：

```text
SourceService.configure_basic_v2(request, *, correlation_id=None)
SourceService.configure_basic_live_v2(request, *, correlation_id=None)
SourceService.set_output_v2(request, *, correlation_id=None)
SourceService.configure_counter_v2(request, *, correlation_id=None)
SourceService.set_counter_enabled_v2(request, *, correlation_id=None)
SourceService.measure_counter_v2(request, *, correlation_id=None)
SourceService.configure_harmonics_v2(request, *, correlation_id=None)
SourceService.disable_harmonics_v2(request, *, correlation_id=None)
SourceService.configure_modulation_v2(request, *, correlation_id=None)
SourceService.configure_pm_modulation_v2(request, *, correlation_id=None)
SourceService.configure_fm_modulation_v2(request, *, correlation_id=None)
SourceService.configure_pwm_modulation_v2(request, *, correlation_id=None)
SourceService.configure_sweep_v2(request, *, correlation_id=None)
SourceService.configure_burst_v2(request, *, correlation_id=None)
SourceService.configure_pulse_v2(request, *, correlation_id=None)
SourceService.mutate_arbitrary_storage_v2(request, *, payload, correlation_id=None)
SourceService.select_arbitrary_v2(request, *, correlation_id=None)
wavebench source basic-configure-v2 --channel N ...
wavebench source basic-live-configure-v2 --channel N (--frequency-hz HZ | --amplitude-vpp VPP)
wavebench source output-v2 --channel N on|off
wavebench source counter-configure-v2 --input-id INPUT_ID <one configuration option>
wavebench source counter-enable-v2 --input-id INPUT_ID
wavebench source counter-disable-v2 --input-id INPUT_ID
wavebench source counter-measure-v2 --input-id INPUT_ID
wavebench source harmonics-configure-v2 --channel N --order N --preset all|even|odd
wavebench source harmonics-disable-v2 --channel N
wavebench source modulation-configure-v2 --channel N --depth-percent PERCENT --internal-frequency-hz HZ
wavebench source pm-modulation-configure-v2 --channel N --phase-deviation-deg DEG --internal-frequency-hz HZ
wavebench source fm-modulation-configure-v2 --channel N --frequency-deviation-hz HZ --internal-frequency-hz HZ
wavebench source pwm-modulation-configure-v2 --channel N --internal-frequency-hz HZ (--duty-deviation-percent PERCENT | --width-deviation-s S)
wavebench source sweep-configure-v2 --channel N --start-hz F --stop-hz F --spacing linear|logarithmic|step --steps N --sweep-time-s S
wavebench source burst-configure-v2 --channel N --cycles N --phase-deg DEG --internal-period-s S --delay-s S
wavebench source pulse-configure-v2 --channel N --width-s S --delay-s S --leading-transition-s S --trailing-transition-s S
wavebench source arbitrary-storage-v2 --channel N --slot-id SLOT --payload-file FILE --write-mode create-only|replace-if-digest-matches [--expected-previous-sha256 SHA256]
wavebench source arbitrary-select-v2 --channel N --slot-id SLOT --playback-mode dds|true-arb (--playback-frequency-hz HZ | --sample-rate-hz HZ)
```

十六个 mutation Service 方法分别返回 `(typed_result, operation_artifact)`；
`measure_counter_v2()` 是只读方法，直接返回 `SourceCounterMeasureResult`。`operation_artifact` 使用
`wavebench.source.operation.v1`，不得包含 raw SCPI、完整响应、资源地址、序列号、授权 token 或 nonce。

`source.harmonics_configure_v2` 只允许单通道的 `all`、`even`、`odd` 预设。descriptor 必须同时声明
Harmonic `READ`／`CONFIGURE`、允许的 order 区间和预设，以及 configured order、preset 与输出状态的可读回。
请求中的 `order` 必须落在运行时 profile 范围内；配置前后目标输出都必须回读为 OFF。该 operation 不提供
USER mask、逐分量幅度或相位、默认值重置，也不会隐式开启输出。

`source.harmonics_disable_v2` 只接受单通道 request。descriptor 必须同时声明 Harmonic `READ`／`DISABLE`
与 output state readback；配置前后目标输出均须为 OFF，结果与独立 postcondition 都须确认
`harmonics.enabled = false`。已关闭状态只产生 fresh readback，不发送重复写入；该 capability 不要求 order、
preset 或分量 readback，也不授权输出 ON。

`source.modulation_configure_v2` 只允许单通道、输出 OFF 时的内部正弦 AM。descriptor 必须同时声明
Modulation `READ`／`CONFIGURE`、`am`、`internal`、`depth_percent` 与 `configuration_readable = true`，并能回读
同一 channel 的 output state。请求中的深度必须位于 `[0, 100]`，内部频率必须为有限正值；该 operation 不提供
disable、外部调制源、内部波形选择、FM／PM／PWM 或隐式输出 ON。

`source.modulation_pm_configure_v2` 只允许单通道、输出 OFF 时的内部正弦 PM。descriptor 必须同时声明
Modulation `READ`／`CONFIGURE`、`pm`、`internal`、`phase_deviation_deg` 与 `configuration_readable = true`，并能回读
同一 channel 的 output state。请求中的相位偏差必须位于 `[0, 360]`，内部频率必须为有限正值；该 operation 不提供
disable、外部调制源、内部波形选择、AM／FM／PWM 或隐式输出 ON。

`source.modulation_fm_configure_v2` 只允许单通道、输出 OFF 时的内部正弦 FM。descriptor 必须同时声明
Modulation `READ`／`CONFIGURE`、`fm`、`internal`、`frequency_deviation_hz` 与 `configuration_readable = true`，并能
回读同一 channel 的 output state。frequency deviation 与内部频率均必须为有限正值；该 operation 不提供
disable、外部调制源、内部波形选择、AM／PM／PWM 或隐式输出 ON。

`source.modulation_pwm_configure_v2` 只允许单通道、输出 OFF 时的内部正弦 PWM。descriptor 必须同时声明
Modulation `READ`／`CONFIGURE`、`pwm`、`internal`、`configuration_readable = true`，且 `parameter_kinds` 至少包含
`duty_deviation_percent` 或 `width_deviation_s` 之一，并能回读同一 channel 的 output state。request 包含有限正值
`internal_frequency_hz`，以及恰好一个显式单位分支：`[0, 50]` 的 `duty_deviation_percent` 或 `[0, 500000]` 秒的
`width_deviation_s`；该 operation 不提供 disable、外部调制源、内部波形选择、AM／FM／PM 或隐式输出 ON。

`source.sweep_configure_v2` 只允许单通道、输出 OFF 时的内建 Sweep。descriptor 必须同时声明 Sweep
`READ`／`CONFIGURE`、至少一个 spacing、internal trigger、timing／marker 与 `configuration_readable = true`；同一 channel
的 Basic `READ` 必须声明 `sweep` frequency mode，Output `READ` 也必须能够回读 output state。request 包含有限正值且 start 不大于 stop 的
start/stop、一个已声明的 spacing、`[2, 2048]` 的 steps 和 `[0.001, 300]` 秒的 sweep time。配置后必须回读 Basic 的
`frequency_mode = sweep`、enabled Sweep、零 hold／return、internal positive trigger、trigger output OFF、marker disabled
及全部 request 字段。它不提供 center/span、marker、外部／手动 trigger、arm、fire、输出 ON 或返回固定频率。

`source.burst_configure_v2` 只允许单通道、输出 OFF 时的内部 Triggered Burst。descriptor 必须同时声明
Burst `READ`／`CONFIGURE`、`triggered`、`internal`、`timing_readable = true` 与
`triggered_internal_configuration_readable = true`，并能回读同一 channel 的 output state。request 包含
`cycles`、`phase_deg`、`internal_period_s` 与 `delay_s`；配置后必须回读 enabled、Triggered mode、内部正触发、
trigger output OFF 和全部 request 字段。它不提供 Gated、Infinity、外部／手动 trigger、arm、fire、输出 ON 或隐式恢复。

`source.pulse_configure_v2` 只允许单通道、输出 OFF 时的 WIDTH 脉冲形状。descriptor 必须同时声明
Pulse `READ`／`CONFIGURE`、WIDTH hold、delay、transition 与 `width_configuration_readable = true`，并能回读
同一 channel 的 output state。请求中的 width 不得小于 `4 ns`，delay 必须为有限非负值，两个 transition 必须为
有限正值且各自不超过 width 的 `0.625` 倍；该 operation 不提供 DUTY hold、partial patch、trigger、输出 ON 或隐式波形切换。

`source.arbitrary_storage_v2` 与 `source.arbitrary_select_v2` 始终是两个 operation。storage request 只携带
channel、slot、write mode、SHA-256、大小和 compare-and-replace 的旧摘要；payload 以独立 `bytes` 参数交给 driver，
不会进入 artifact。声明 storage capability 的 descriptor 必须同时声明 ARB `READ`／`CONFIGURE`、可读 selection／output、
`storage_slot_metadata_readable = true`、非空 `storage_write_modes` 和正的 `storage_max_payload_bytes`。core 预读指定槽位，
driver 必须执行原子 create/CAS，核心再独立回读槽位、selection 与 output。storage 不强制端口 OFF，也不允许隐式 selection 或 ON。

selection request 使用 DDS 的 `playback_frequency_hz` 或 true-ARB 的 `sample_rate_hz`，两者互斥。它要求 target output OFF，
并回读 Basic `arbitrary` waveform、selected slot、mode、对应速率和 storage digest；它不会授权 output ON。若声明任一
ARB V2 capability，V1 `upload_arbitrary_waveform` 会在读取本地 waveform 文件、构造块或发送仪器 I/O 前拒绝。

run plan 接受 `source.basic_configure_v2`、`source.basic_live_configure_v2`、`source.output_enable_v2`、`source.output_disable_v2`、
`source.counter_configure_v2`、`source.counter_enable_v2`、`source.counter_disable_v2`、`source.counter_measure_v2`、
`source.harmonics_configure_v2`、`source.harmonics_disable_v2`、`source.modulation_configure_v2`、`source.modulation_pm_configure_v2`、`source.modulation_fm_configure_v2`、`source.modulation_pwm_configure_v2`、`source.sweep_configure_v2`、`source.burst_configure_v2`、`source.pulse_configure_v2`、`source.arbitrary_storage_v2`、`source.arbitrary_select_v2`、`source.combine_configure_v2`、`source.coupling_configure_v2`、`source.tracking_configure_v2` 与 `source.phase_relation_configure_v2` 二十三个 Source V2 step；mutation artifact 只在实际执行时写入
`run.json.source_operations`，而 `source.counter_measure_v2` 使用其 step 专有的 `counter_measurement` artifact。

旧 `source.*` setter、output、trigger 和 ARB 路径继续保留。双合同插件上，四个 basic setter 与
`set_output` 会进入相应 V2 transaction；restore、ARB upload 和 V2 output 重叠的 trigger 在仪器 I/O 前
拒绝。双合同插件声明 `source.harmonics_configure_v2` 或 `source.harmonics_disable_v2` 时，V1 `configure_harmonics` 和 basic restore
在仪器 I/O 前拒绝；声明 `source.modulation_configure_v2` 时，V1 `configure_am_modulation` 和 basic restore
也在仪器 I/O 前拒绝；声明 `source.modulation_pm_configure_v2` 时，V1 `configure_pm_modulation` 和 basic restore
也在仪器 I/O 前拒绝；声明 `source.modulation_fm_configure_v2` 时，V1 `configure_fm_modulation` 和 basic restore
也在仪器 I/O 前拒绝；声明 `source.modulation_pwm_configure_v2` 时，V1 `configure_pwm_modulation` 和 basic restore
也在仪器 I/O 前拒绝；声明 `source.sweep_configure_v2` 时，V1 `configure_sweep`、`trigger_sweep` 和 basic restore
也在仪器 I/O 前拒绝；声明 `source.burst_configure_v2` 时，V1 `configure_burst`、`trigger_burst` 和 basic restore
也在仪器 I/O 前拒绝；声明 `source.pulse_configure_v2` 时，V1 `configure_pulse` 和 basic restore 也在仪器 I/O 前拒绝；
声明任一 ARB V2 capability 时，V1 `upload_arbitrary_waveform` 也在本地文件读取和仪器 I/O 前拒绝。其余尚无对应 V2
capability 的高级配置保持 V1。插件不得把 capability 注册视为
自行发起写操作的许可，也不得通过已有 V1 方法绕过核心路由。

### RF 信号源 M0–M4（DSG830 production 已含 A2 output、A3 CW、A4 调制／Pulse／Step Sweep）

`rf_source` 是独立于 `source` 的 kind，不能使用 `source_extensions`、Vpp、数字 channel 或普通 source
能力。descriptor 必须同时满足以下静态条件：

- 只声明 `rf_source.*` capability，且至少包含 `rf_source.idn`；当前 Core 识别
  `rf_source.idn`、`rf_source.snapshot`、`rf_source.cw_configure`、`rf_source.modulation_configure`、`rf_source.modulation_disable`、`rf_source.pulse_configure`、`rf_source.sweep_configure` 和 `rf_source.output`。
- 提供 `rf_source_extensions`，其 contract version、拓扑、端口 ID、feature 和 protection policy 必须通过
  Core 校验。
- 声明 `rf_source.cw_configure` 时，CW feature 必须有 `CONFIGURE` direction 和至少一个可配置字段；声明
  `rf_source.output` 时，output feature 必须同时有 `ENABLE`／`DISABLE` direction 与可读 output state。
- 声明 `rf_source.modulation_configure` 时，Modulation feature 必须同时有 `CONFIGURE`／`READ` direction、
  `configuration_readable = true`，并至少声明一个内部 Sine `RfModulationModeProfile`。profile 的模式、值单位、值范围和内部频率范围必须与 driver 的严格 readback 一致。
- 声明 `rf_source.pulse_configure` 或 `rf_source.sweep_configure` 时，对应 feature 必须同时有 `CONFIGURE`／`READ` direction、可读 configuration state 和有界的 mode profile；Pulse 与 Sweep 的配置方法必须在独立 readback 后保持 disabled。
- `wavebench_min_version` 不低于 `0.8.25`，并且小于 `wavebench_max_version`。
- 打包检查时，wheel 必须有且仅有一条生效的 `wavebench` 依赖，并显式使用与 descriptor 相同的
  `>=wavebench_min_version,<wavebench_max_version` 区间。

| capability | 必须可调用的方法 | 当前 Core 入口 |
| --- | --- | --- |
| `rf_source.idn` | `idn` | `wavebench rf-source idn`、doctor IDN target |
| `rf_source.snapshot` | `get_rf_snapshot` | `wavebench rf-source status`、`rf_source.status` run step |
| `rf_source.cw_configure` | `configure_cw` | `rf-source set-frequency`／`set-power`、对应 run step；OFF-only 合同，DSG830 经 A3 复核后已提升 |
| `rf_source.modulation_configure` | `get_rf_modulation_snapshot`、`configure_rf_modulation` | `rf-source modulation configure-am`／`configure-fm`／`configure-pm`、`rf_source.modulation_configure` run step；内部 Sine、RF OFF、无重试合同，DSG830 经 A4 复核后已提升。AM `0–100 %`、FM `0.1 Hz–1 MHz`、PM 精确 `1.25 rad`，均为 `10 Hz–100 kHz` 内部频率。 |
| `rf_source.modulation_disable` | `get_rf_modulation_state`、`disable_rf_modulation` | 仅用于受控本地证据与恢复；DSG830 不声明 production capability |
| `rf_source.pulse_configure` | `get_rf_pulse_snapshot`、`configure_rf_pulse` | `rf-source pulse configure`、`rf_source.pulse_configure` run step；internal／single、RF OFF，配置后保持 Pulse disabled，DSG830 经 A4 Pulse 复核后已提升 |
| `rf_source.sweep_configure` | `get_rf_sweep_snapshot`、`configure_rf_sweep` | `rf-source sweep configure`、`rf_source.sweep_configure` run step；固定 `STEP`／`FWD`／`RAMP`／`LIN`、RF OFF，配置后保持 Sweep disabled，DSG830 经 A4 Step Sweep 复核后已提升 |
| `rf_source.output` | `set_rf_output` | `rf-source output`、`rf_source.output_enable`／`output_disable` run step；端口级 ON/OFF，受 capability、access、profile 和 fresh safety preflight 共同门禁 |

`RfSourceDriver`、`RfSourceSnapshot`、`RfSourceDescriptorExtensions` 和相关类型均从
`wavebench.instruments` 导入。`rf_source.snapshot` 缺失时，status 入口会在 transport I/O 前拒绝；实现
`get_rf_snapshot()` 本身不会形成隐式 capability。M1／M2／M3／M4 的 CLI 与 run step 也是 capability、access、
profile 和 fresh preflight 的共同门禁；实现 `configure_cw()`、`configure_rf_modulation()`、`configure_rf_pulse()`、`configure_rf_sweep()` 或 `set_rf_output()` 本身不会形成隐式
capability。M3 request 只能选择内部 Sine AM／FM／PM 中的一种，并分别使用 percent、Hz 或 rad 值字段；对共享 FM／PM 选择位的设备，snapshot 必须将当前选择与被查询 profile 分开表示，preflight 只能在所有模式关闭时接受不同选择，postcondition 必须确认目标选择。driver 不得扩展外部 source、其它波形、IQ、Pulse trigger、Sweep execute／fire、Level Sweep、list 或 raw SCPI passthrough。production capability 必须按 [RF 信号源开发里程碑](../project/design/WaveBench_RF信号源开发里程碑.md)
的 A 级实机证据逐项提升，不能由 descriptor 静态校验或 fake transport 测试替代。

### Power、DMM 和 sweep analyzer

| capability | 必须可调用的方法 |
| --- | --- |
| `power.idn` | `idn` |
| `power.status` | `get_status` |
| `power.measurement` | `get_measurement` |
| `power.set_voltage_current_limit` | `set_voltage_current_limit` |
| `power.output` | `set_output` |
| `power.protection` | `get_protection_status`、`set_protection` |
| `dmm.idn` | `idn` |
| `dmm.read` | `read` |
| `dmm.function_status` | `function_status` |
| `dmm.set_function` | `set_function` |
| `dmm.measurement_profile` | `measurement_profile` |
| `dmm.trigger_status` | `trigger_status` |
| `dmm.calculation_status` | `calculation_status` |
| `dmm.calculation_statistics` | `calculation_statistics` |
| `dmm.system_interface_status` | `system_interface_status` |
| `dmm.set_voltage_range` | `set_voltage_range` |
| `dmm.set_dcv_impedance` | `set_dcv_impedance` |
| `sweep_analyzer.idn` | `idn` |
| `sweep_analyzer.status` | `get_snapshot` |
| `sweep_analyzer.trace` | `fetch_frequency_response` |
| `sweep_analyzer.configure` | `apply_sweep_plan` |
| `sweep_analyzer.trigger` | `trigger_single` |
| `sweep_analyzer.output` | `set_source_output` |
| `sweep_analyzer.marker` | `read_markers` |
| `sweep_analyzer.analysis` | `read_measurements` |

`DmmDriver` 还定义了 `apply_function()`。当前 capability 校验只要求 `dmm.set_function` 对应的 `set_function()`；TUI 的复用 session 路径会调用 `apply_function()`。需要支持 TUI 的 DMM 插件必须同时实现这两个方法，并为这一差异添加测试。

## 参数和返回 model

公共 model 用于跨插件保持单位、字段和序列化语义一致。driver 不得返回自定义 dict 代替 Protocol 规定的 model，也不得复制一套同名 dataclass。

| kind | 常用公共返回类型 |
| --- | --- |
| scope | `WaveformHeader`、`WaveformData`、`ScopeSnapshot`、`ScopeAcquisitionStatus` 及各分析 model |
| source | `SourceStatus`、`SourceChannelProfile`、各配置和 profile model；Source V2 使用 `SourceQueryExecutionRecord`，最终 snapshot 由核心构造 |
| power | `PowerStatus`、`PowerMeasurement`、`PowerProtectionStatus` |
| dmm | `DmmReading`、`DmmMeasurementProfile`、各状态和配置 model |
| sweep analyzer | `SweepPlan`、`SweepAnalyzerSnapshot`、`FrequencyResponseTrace`、`TraceIntegrity`、`MarkerReading`、`InstrumentMeasurementResult` |

部分 model 会在 `__post_init__` 中检查有限值、数组维度、字段组合和枚举，另一些只是 frozen 数据容器。插件测试仍需检查以下内容：

- 数值单位与字段名符合公共 model；
- 波形和 trace 数组是一维、有限值，点数与 header 或 integrity 一致；
- 时间戳包含时区；
- 状态查询不隐式修改仪器；
- 写操作返回写后只读核对得到的状态，而不是直接回显请求参数。

## 异常、日志、重试和 session 合同

异常分类见[错误 Reference](../reference/errors.md)。插件侧约定如下：

- 无效调用参数或无法解释的仪器响应使用 `DataError`。
- 仪器错误队列、写后核对失败或设备状态不满足操作条件使用 `InstrumentError`。
- 连接和超时异常由核心 transport 保留其结构化类型；插件不得把 `TransportIOError` 或 `SessionHealthError` 包装成 `OperationTimeout`、`StateDriftError` 或普通 `RuntimeError`。
- 配置、descriptor 和 factory 创建失败由核心转换为 `ConfigError`；运行中的设备数据错误不应伪装成配置错误。
- 所有 I/O 通过核心 transport 执行，并为每个 query 显式传入 `replay=ReplayPolicy.NO_REPLAY`、
  `SAFE_TO_REPLAY` 或 `READ_CONTINUATION_ONLY`。第三方旧调用不需要改语法，但核心默认按
  `no_replay` 处理；插件不能依赖 `read_retry_attempts` 隐式重放。
- 不得自动重试写命令、输出切换、手动 trigger 或已经开始消费响应的数据传输。
- `uncertain` 或 `poisoned` session 上，普通 driver 方法必须在 transport I/O 前失败；
  `on_failure = "continue"` 不能触发第二次恢复或验证写入。
- 恢复/验证授权、字段证据记录和 session 健康回转属于核心内部合同，插件只能实现已冻结的
  有界动作，不能构造授权 token、提交任意字段闭包或开放 raw SCPI 通道。
- capture/fetch 临时修改的厂商状态必须映射到核心字段 ID，不得把厂商命令名注册成新的公共字段。
  query 响应头、波形字节序和传输窗口分别使用 `scope.query_response_header`、
  `scope.waveform_byte_order` 和 `scope.waveform_transfer_window`。其中 transfer window 是完整的
  原子选择状态，包含后端支持的稀疏率、点数、首点和分段选择，不能只核对其中一部分。
- `verification_fields` 只定义恢复后必须取得的证据范围。恢复写入成功不等于验证成功；插件必须
  通过独立 readback 和规范化比较提供结果，核心 coordinator 才能记录字段证据。缺少任何必验字段
  时保持 fail closed，插件不得自行把 session 改回 `healthy`。
- driver 不得吞掉错误后返回伪造的成功状态。

核心 R1 当前已在开发分支实现但尚未发布。插件 wheel 的 `Requires-Dist`、descriptor
`wavebench_min_version` 和 `api_version` 在包含 R1 的核心版本发布前不得提高；升级前还要
补齐结构化异常优先级、恢复失败后零二次 I/O 和发送次数断言。

## 当前不会自动校验的项目

以下内容属于插件发布门槛，但当前核心不会完整验证：

| 项目 | 插件侧验证方式 |
| --- | --- |
| `driver_id` 的小写 dotted 命名 | descriptor 单测 |
| capability 前缀与 `kind` 一致 | 集合断言 |
| `OptionSpec.name` 唯一 | descriptor 单测 |
| 方法签名和返回类型符合 Protocol | fake transport 单测和静态类型检查 |
| `permissions` 对应真实行为 | 人工审查；该字段当前不授权 |
| `config_fields` 与配置文档一致 | 文档测试或快照测试 |
| `idn_patterns` 能区分设备族 | 脱敏 IDN 样本测试 |
| `close()` 真正释放 transport | 失败注入和 close 次数测试 |
| 导入 descriptor 无 I/O 副作用 | 子进程导入测试 |

## 兼容性

插件包有两层版本门：

1. wheel metadata 中的 `Requires-Dist: wavebench...`；
2. descriptor 的 `wavebench_min_version` 和 `wavebench_max_version`。

两层都必须包含当前 WaveBench 版本。descriptor 区间为左闭右开；`api_version` 则要求精确字符串相等。

以下变更应视为不兼容：

- 修改现有 capability 的方法名、参数或返回 model；
- 改变字段单位、枚举含义或写操作的副作用；
- 让原本只读的方法开始写入或触发；
- 更换 canonical `driver_id` 指向的设备族；
- 缩小已发布 model 的有效输入范围，导致旧插件对象无法构造。

新增独立 capability、model 的可选字段或 descriptor 展示字段，通常可以保持现有插件兼容。标准 waveform
的 `waveform_binary_profile` 与 average 的 `average_capture_profile_v2` 和各自 bounded Protocol 组是已冻结的
V2 additive 例外：只有相应 profile 非空的 descriptor 改用新方法集，旧 `ScopeDriver` 方法不变。每次提高最低
WaveBench 版本时，应同步修改 wheel 依赖、descriptor 区间和插件测试矩阵。

## 最小验证矩阵

发布前至少覆盖：

- descriptor 子进程导入无 I/O；
- entry point 名、canonical ID、kind、API 版本和兼容区间；
- capability 前缀、方法存在性、签名和返回 model；
- `OptionSpec` 的默认值、required、类型、范围、choices、未知键和重名；
- fake transport 下的正常、超时、短响应、坏数据、错误队列和 close；
- factory 抛错、capability 不完整、`close()` 抛错和第二次 transport 请求；
- 只读方法无写命令，写操作无隐藏 output 或 trigger；
- wheel 包检查、一次性 venv 安装、`plugin doctor --load` 和卸载；
- 如使用受限覆盖槽位，验证 canonical ID 选择外置实现、短 alias 保留内置实现、卸载后回退。

示例命令：

```bash
python -m pytest -q
python -m ruff check .
python -m wavebench plugin package check ./dist/plugin.whl
python -m wavebench plugin install ./dist/plugin.whl --dry-run
python -m wavebench plugin doctor --load
```

默认测试不得扫描端口、连接仪器或发送 SCPI。实机验收应单独授权，并使用脱敏配置和可恢复的状态检查。
