# 归档：重构前的 WaveBench run plan 使用指南

> [!NOTE]
> 本页保留了文档重构前的完整 run plan 指南，供追溯和迁移核对使用。它混合了教程、How-to、schema、artifact、频响、Source V2 和历史说明，不能作为当前字段、capability 或型号状态的唯一来源。请从[执行一次实验](../how-to/run-an-experiment.md)、[从模板到报告](../tutorials/from-template-to-report.md)、[run plan Reference](../reference/run-schema.md)和[运行产物 Reference](../reference/artifacts.md)开始。

本页面向需要编写 plan 的开发者。重点是现场快速编写、检查 plan，并定位失败原因；内部实现不在本页展开。

除非单独标注，带 `^` 的多行命令示例使用 PowerShell 续行；bash / zsh 可把 `^` 换成 `\`，或直接写成一行。

## 先看 schema，再写 plan

先运行：

```powershell
python -m wavebench run schema
```

它会列出当前代码真正支持的 step kind、必填字段和可选字段。文档可能会落后，`run schema` 以当前代码为准。

接线或 IP 可能变动时，先跑只读 doctor：

```powershell
python -m wavebench doctor --config wavebench.toml

python -m wavebench doctor --config wavebench.toml ^
  --discover-subnet 192.0.2.0/24 ^
  --discover-timeout-ms 500
```

`doctor` 会对配置里的 scope/source/power/dmm 做只读 `*IDN?` 检查，确认资源可达、型号匹配，并给出排错建议。`--discover-subnet` 只在配置资源不可达或型号不匹配时扫描候选资源；它只建议替代 `resource`，不会修改配置。

最小流程：

```powershell
python -m wavebench run schema
python -m wavebench run check  --config wavebench.toml --plan plans/example_scope_expect_quality.toml
python -m wavebench run verify --config wavebench.toml --plan plans/example_scope_expect_quality.toml
python -m wavebench run plan   --config wavebench.toml --plan plans/example_scope_expect_quality.toml
```

`run check` 只解析 plan 并打印摘要，不连接仪器；`run verify` 执行只读资源和安全预检；`run plan` 才会真实执行。

## 执行意图与摘要核验

需要把计划交给另一个进程或在执行前固定输入时，可以先生成执行意图：

```powershell
python -m wavebench run intent --config wavebench.toml --plan plans/example_scope_expect_quality.toml ^
  --output data/intents/example.json

python -m wavebench run plan --config wavebench.toml --plan plans/example_scope_expect_quality.toml ^
  --intent data/intents/example.json
```

执行意图使用 `wavebench.execution_intent.v1`，包含 plan/config 摘要、任意波形 payload 摘要和每个
step 的 `OperationSpec`。`run plan --intent` 会在取得资源租约、打开仪器 session 前重新计算摘要；
计划、配置或 payload 发生变化时返回 `execution_intent_mismatch`。未提供外部意图文件时，run 仍会
把生成的意图写入 `run.json.provenance.execution_intent`。

## run plan 的 session 生命周期

`run plan` 会在一次 run 开始时为 plan 需要的仪器统一打开 session，并在 safety guard、snapshot/restore 和所有 step 之间复用这些 session。run 成功、step 失败、safety guard 失败或 restore 失败时，都会统一关闭已经打开的 session。

这和普通 CLI one-shot 命令不同：

- `power status`、`source set-freq` 这类单次 CLI 命令仍然是一次操作打开一次、结束关闭。
- `run plan` 是整次实验持有 session，减少同一 plan 内反复连接/断开的开销，也让 safety、采集和 restore 使用同一批仪器连接。
- 当前第一版不做长 session 断线自动重建；如果 run 中途断线，应该让 run 失败并留下 `run.json` 证据，而不是偷偷重连后继续。

## RF 信号源步骤

RF 使用独立的 `rf_source.*` step，不使用普通 `source` 的 channel、Vpp、restore 或 safety 语义。当前 DSG830 production descriptor 已开放只读状态、OFF-only CW、RF-OFF 内部正弦调制、受 safety 限制的 RF 输出、internal／single Pulse 和保持 Sweep disabled 的 frequency-only Step Sweep 配置：

```toml
[[steps]]
kind = "rf_source.set_frequency"
port_id = "rf_out"
frequency_hz = 1000000

[[steps]]
kind = "rf_source.set_power_dbm"
port_id = "rf_out"
power_dbm = -40

[[steps]]
kind = "rf_source.output_enable"
port_id = "rf_out"

[[steps]]
kind = "rf_source.output_disable"
port_id = "rf_out"

[[steps]]
kind = "rf_source.pulse_configure"
port_id = "rf_out"
period_s = 0.001
width_s = 0.0001
polarity = "normal"

[[steps]]
kind = "rf_source.sweep_configure"
port_id = "rf_out"
start_frequency_hz = 1000000
stop_frequency_hz = 2000000
points = 11
dwell_s = 0.02
```

CW、Pulse 和 Step Sweep 配置均要求 RF 输出明确 OFF，且调制、Pulse、Sweep 与 protection 没有冲突。Pulse 只支持 internal／single，配置后保持 disabled；Step Sweep 固定为 `STEP`／`FWD`／`RAMP`／`LIN`，不 arm、fire、trigger、execute、配置 Level Sweep 或切换 RF 输出，配置后保持 disabled。`rf_source.output_enable` 还会检查每端口安全配置、实际端接、频率、功率和 fresh snapshot；不满足时会在 ON 前拒绝。RF operation 的类型化 artifact 写入 `run.json.rf_source_operations`。

Core 已在 schema 中提供 M3 的 `rf_source.modulation_configure`：

```toml
[[steps]]
kind = "rf_source.modulation_configure"
port_id = "rf_out"
modulation_kind = "fm"
frequency_deviation_hz = 10000
internal_frequency_hz = 1000
```

`modulation_kind` 为 `am`、`fm` 或 `pm`，分别只能使用 `depth_percent`、`frequency_deviation_hz` 或 `phase_deviation_rad`。它只覆盖内部 Sine，要求 RF OFF、所有调制模式 disabled、Pulse／Sweep disabled 和无活动 protection condition。DSG830 production descriptor 已声明调制 capability，profile 为 AM `0–100 %`、FM `0.1 Hz–1 MHz`、PM 精确 `1.25 rad`，且内部频率均为 `10 Hz–100 kHz`。不要把它与 `rf_source.output_enable` 拼成「调制输出」流程：当前 ON 合同要求调制 disabled。

RF 的配置、端接判断、CLI 与 A4 边界见 [RF 信号源使用指南](../project/guides/WaveBench_RF信号源使用指南.md)。

## 不想手写时先用模板

`run template` 只负责生成标准 TOML plan，不连接仪器、不改配置、不覆盖已有文件（除非传 `--force`）。生成后仍然走普通流程：`run check`、`run verify`、`run plan`、`run report`。

常用模板：

```powershell
python -m wavebench run template --list

python -m wavebench run template source-scope-sine ^
  --frequency 1000 ^
  --vpp 1.0 ^
  --source-channel 1 ^
  --scope-channel 1 ^
  --output plans/source_scope_sine_1k.toml

python -m wavebench run template source-scope-sweep ^
  --frequencies 100,1000,10000 ^
  --vpp 1.0 ^
  --source-channel 1 ^
  --scope-channel 1 ^
  --output plans/source_scope_sweep.toml

python -m wavebench run template source-scope-frequency-response ^
  --frequencies 100,1000,10000 ^
  --source-channel 1 ^
  --reference-channel 1 ^
  --response-channel 2 ^
  --fit ^
  --output plans/source_scope_frequency_response.toml

python -m wavebench run template dmm-acv-source ^
  --frequency 1000 ^
  --vpp 1.0 ^
  --source-channel 2 ^
  --output plans/dmm_acv_source_smoke.toml

python -m wavebench run template power-dmm-dcv ^
  --voltage 3.3 ^
  --current-limit 0.1 ^
  --power-channel 1 ^
  --output plans/power_dmm_dcv_smoke.toml
```

模板边界：

- `source-scope-sine`：生成单频点 DG4202 -> RTM2032 完整流程 plan，带 source restore、scope safety、质量检查、`[steps.expect]` 和 `[steps.expect_fft]`。
- `source-scope-sweep`：把 `--frequencies` 里的频点展开成多组 `source.set_freq` + `scope.capture`，每个频点都有独立 label、expect 和 FFT expect。它不是新的执行器，只是 run plan 展开器。
- `source-scope-frequency-response`：生成一次同步双通道采集的频响 plan。reference 通道接 DUT 输入，response 通道接 DUT 输出；`--fit` 额外写入线性增益拟合配置。
- `dmm-acv-source`：生成 DG4202 -> DMM ACV smoke plan，ACV 期望值按 `Vpp / (2 * sqrt(2))` 自动缩放。
- `power-dmm-dcv`：生成 DP800 电压设置 + DMM DCV 读回 plan，只设置电压/限流，不自动打开或关闭电源输出。

模板生成后建议立刻跑：

```powershell
python -m wavebench run check  --config wavebench.toml --plan plans/source_scope_sweep.toml
python -m wavebench run verify --config wavebench.toml --plan plans/source_scope_sweep.toml
```

## 双通道频率响应 / Frequency response

`sweep.frequency_response` 让信号源按离散频点设定频率，并让示波器在每个频点只触发一次、同步读取两路波形：

- `reference_channel` 是 DUT 输入参考；`response_channel` 是 DUT 输出，二者必须不同。
- source 输出必须已经由前面的显式 `source.output state = "on"` 打开。频响 step 不会偷偷打开输出；若输出关闭或设频写入失败，会立即停止后续频点并走已有 restore 路径。
- 两路都会经过高阻保护。执行前仍需人工确认探头、线缆、量程和接地；WaveBench 不自动 deskew，也不会把测得相位冒充为已校准 DUT 相位。
- 每个成功采集强制保存双路 NPY 与 `metadata.json` 作为原始证据，即使全局输出配置关闭了 NPY/JSON。采集或分析失败会写入该频点 CSV 行后继续；信号源状态/写入异常会停止。
- 一个 plan 可以包含多个该 step，但每个 `label` 必须唯一；多 response 会写根目录 `frequency_responses.json`，每个响应使用独立子目录，因此不会覆盖产物。

显式频点示例：

```toml
[[steps]]
kind = "source.output"
channel = 1
state = "on"

[[steps]]
kind = "sweep.frequency_response"
label = "lowpass_bode"
source_channel = 1
reference_channel = 1
response_channel = 2
frequencies_hz = [100, 316.228, 1000, 3162.28, 10000]
target_cycles = 10
settle_s = 0.3
points = "def"
save_csv = false
screenshot = true

[steps.fit]
methods = ["linear_log", "polynomial", "pchip", "smoothing_spline_db", "piecewise_chebyshev_db"]
polynomial_degree = 2
```

也可让 parser 生成等比或等差频点：

```toml
[[steps]]
kind = "sweep.frequency_response"
reference_channel = 1
response_channel = 2
start_frequency_hz = 100
stop_frequency_hz = 100000
frequency_count = 31
spacing = "log" # "log" 或 "linear"
```

### 二维 Vpp × 频率扫频与自动校准

默认频响 plan 是一个固定源幅值切片。需要观察增益随输入幅值变化、或为数字后端生成二维 LUT 时，在同一个 step 中额外给出请求 Vpp 轴。可以显式列举，或用首末值和步进生成；两种写法不能混用：

```toml
[[steps]]
kind = "sweep.frequency_response"
source_channel = 1
reference_channel = 1
response_channel = 2
start_frequency_hz = 10000
stop_frequency_hz = 500000
frequency_count = 246
spacing = "linear"
start_vpp = 0.005
stop_vpp = 0.250
vpp_step = 0.005
target_cycles = 10
settle_s = 1.0

[steps.calibration]
target_mode = "passband_median"
correction_min_db = -12
correction_max_db = 12
max_slope_db_per_octave = 6
```

等价的显式幅值写法为 `amplitudes_vpp = [0.005, 0.010, 0.020]`。每个值都是信号源**请求/设定** Vpp；`reference_vpp_v` 始终保留为示波器 CH1 的实测审计量，二者不可互换。

| 字段 | 含义与限制 |
|---|---|
| `amplitudes_vpp` | 严格递增、正数的显式 Vpp 数组；不能与生成式字段共用。 |
| `start_vpp` / `stop_vpp` / `vpp_step` | 三者必须同时出现；`stop_vpp > start_vpp`，步进必须整除区间。 |
| `autoscale_each_amplitude` | 多幅值时默认 `true`；仅在已人工确认量程时才建议设为 `false`。 |
| `retry_warning_with_autoscale` | 默认 `true`；单点出现质量 warning 时 autoscale、稳定后重测一次。重测仍 warning 则该点标为 failed，并保留两次采集证据。 |
| `min_signal_vpp` | 仅本频响 step 的低信号 warning 门限，默认 `0.020` Vpp。若已用实测波形确认低幅值切片仍有足够 SNR，可降低（例如 `0.005`）；它会写入每点原始 metadata 的 operation，不能用来掩盖削顶、频率失配等其他 warning。 |
| `[steps.calibration]` | 仅多幅值数据有实际意义；`enabled = false` 可关闭自动派生。 |

执行顺序固定为「设定 Vpp → 为每个频点设频并等待 `settle_s` → 为每个幅值切片的首个频点执行 autoscale → 再等待 `settle_s` → 同步采集 CH1 / CH2」。`autoscale_each_amplitude = false` 可显式关闭切片首点 autoscale，但仅适用于已确认两路量程足够的情况。每个 Vpp 值都会在连接仪器前接受 `[safety_limits].max_source_vpp` 检查。

频响点的首次采集若出现质量 warning，默认会执行一次「autoscale → 等待 `settle_s` → 同频同幅值重测」。重测成功时，CSV 的最终值来自第二次采集；首次证据保存在 `quality_retry_count`、`initial_warnings`、`initial_capture_package` 和 `initial_metadata_path` 中。重测仍出现 warning 时，该点标为 `failed`，原因设为 `quality_retry_exhausted`，不参与拟合、软件校正或二维 LUT。可在 step 中设置 `retry_warning_with_autoscale = false` 关闭此策略。

每个频响点还会写入稳定的 `case_id`、本次物理采集的 `acquisition_id`、`plan_hash` 和 `capture_sync_grade`。`case_id` 由计划语义、频率、请求 Vpp、通道角色生成，适合跨 run 比较；重测会保留不同的 `acquisition_id`。`reference_vpp_v` 是参考示波器通道的实测值，`requested_source_vpp` 是信号源请求值；系统不会根据输入阻抗自动换算电压。`signal_level_evidence` 会记录参考平面和未执行换算的说明。

频响点级采集或分析失败仍会保留行并继续扫描，这是为了保留完整网格证据。需要在异常累计时停止整组扫描时，可显式设置 `stop_conditions`：

```toml
[steps.stop_conditions]
max_failed_points = 2
max_consecutive_failed_points = 1
max_gain_jump_db = 6
```

达到任一条件后，当前 response 步骤停止，并在 `artifact.frequency_response.stop_conditions` 中保存触发条件；信号源设频、输出状态或通信失败仍会立即停止该步骤。

默认 20 mVpp 的门限是保守质量保护，不是仪器限制。对已确认稳定的低幅值扫频，可只在该 `sweep.frequency_response` 中设置 `min_signal_vpp = 0.005`；这会在采集分析阶段生效，因此 `metadata.json`、CSV 状态和报告审计使用同一个判断依据。全局 `[waveform]` 也可设同名默认值，但不建议为了一个低幅值实验而永久降低所有普通采集的门限。

完整矩阵的点数为 `幅值数 × 频点数`；每个点至少消耗 `settle_s`，每个幅值切片还会增加一次 autoscale 与稳定等待。先用少量幅值和稀疏频点执行 `run check`、只读 `run verify`、再做实机小矩阵确认量程和耗时，别拿 5 mV 步进和 500 Hz 步进直接开 13 小时以上的盲扫，没必要给仪器和人都上强度。

`[steps.calibration]` 需要至少两个请求 Vpp 切片且每个切片至少四个共同有效频点。它会在测量结束后使用每切片的 dB 平滑样条、请求 Vpp 方向线性插值生成校准；频率节点沿用实测点，不在频率或 Vpp 定义域外外推。自动校准失败不会删除或重写原始频响 CSV：该 step 变为 `warning`，`artifact.frequency_response.calibration_error` 记录原因，之后可修正配置或数据再离线重算。

离线重算使用只含 `[calibration]` 的独立 TOML，既不读取 `wavebench.toml`，也不连接仪器：

```powershell
python -m wavebench run calibrate data/runs/<run_dir> --config plans/calibration.toml
```

`run calibrate` 使用的 `[calibration]` 与 plan 内 `[steps.calibration]` 使用同一 schema。除 `enabled`（仅 plan 使用）外，字段如下：

| 字段 | 默认值 | 说明 |
|---|---:|---|
| `model` | `"smoothing_spline_db"` | 当前唯一受支持的二维频率模型。 |
| `target_mode` | `"passband_median"` | `passband_median`、`explicit_gain_db` 或 `unity_gain`。 |
| `target_gain_db` | 无 | `explicit_gain_db` 时必填。 |
| `target_frequency_min_hz` / `target_frequency_max_hz` | 全有效频段 | 仅确定通带中位数目标的频段。 |
| `correction_min_db` / `correction_max_db` | `-12` / `12` | 导出的补偿 dB 边界。 |
| `max_slope_db_per_octave` | `6` | 相邻频率校正的最大斜率，必须大于零。 |
| `chebyshev_degree` / `chebyshev_segment_count` | `3` / `8` | 为需要公式求值的后端导出的近似参数。 |

该命令只覆盖选中 response 目录的 `frequency_response_calibration*` 派生产物，绝不改写 `frequency_response.csv` 或原始采集包。若 manifest 有多个 response，必须显式选择：

```powershell
python -m wavebench run calibrate data/runs/<run_dir> --config plans/calibration.toml --response dut_path
```

### 跨 run 比较与缺失点补测

`run compare` 是离线命令，按 `case_id` 优先、按频率和请求 Vpp 回退，对比增益、相位、参考 Vpp、状态和缺失点。不同通道角色、参考平面或计划哈希会被标记为不兼容，不会静默合并：

```powershell
python -m wavebench run compare data/runs/baseline data/runs/current --gain-tolerance-db 0.5 --phase-tolerance-deg 5 --output reports/frequency_compare.json
```

使用 `--format json` 可将结果直接写到标准输出。比较命令只读取已有 run artifact，不打开仪器。

需要补测缺失点时，先生成离线清单：

```powershell
python -m wavebench run resume data/runs/current --plan plans/lowpass_frequency_response.toml --response dut_path --output reports/frequency_resume.json
```

清单会列出可复用、待补测和被拒绝的点。新 plan 可在对应 response step 中设置 `resume_from = "../data/runs/current/frequency_response.csv"`；WaveBench 只复用计划哈希和案例标识均匹配且状态为 `ok` 的点，原 run 目录不会被改写。

补测清单先覆盖计划声明的初始频率网格；启用自适应加点时，新的中点仍按当前 plan 的自适应规则重新判断。

### 直通基线、软件 deskew 与自适应频率

直通基线必须是**独立 run**：操作者先把 CH1/CH2 手动直通、确认高阻与安全幅度，再按普通 `sweep.frequency_response` 采集。DUT step 只读引用该证据；它不改示波器 deskew 或前面板设置，且 `run check` 会在连接仪器前离线检查基线 response、Vpp 切片和初始频率有效域。

```toml
[[steps]]
kind = "sweep.frequency_response"
label = "dut_path"
source_channel = 1
reference_channel = 1
response_channel = 2
start_frequency_hz = 10000
stop_frequency_hz = 500000
frequency_count = 41
spacing = "log"

[steps.baseline]
run_dir = "../runs/through_baseline"
# response = "through" # 基线 run 有多个 response 时必填
mode = "complex_transfer" # 默认；或 phase_only / delay_only

[steps.adaptive]
enabled = true             # 默认关闭，保持旧 plan 行为
gain_threshold_db = 0.5
phase_threshold_deg = 10
max_levels = 2
max_frequency_points = 1000
```

默认 `complex_transfer` 同时扣除基线 dB 增益和展开相位；`phase_only` 只校正相位；`delay_only` 从基线相位—频率线性拟合估算延迟后校正相位。原始列永远保留，报告并列原始和校正曲线，二维校准默认用校正增益。

自适应先采集初始网格；任一 Vpp 切片相邻点的增益或展开相位达到阈值时加入中点（log 为几何、linear 为算术），每个新频点都采集**所有** Vpp 切片以保持二维矩形网格。它不能发现端点相同而中间存在未采样窄带异常的特征，初始网格仍须覆盖已知关注区域。

### 定点 LUT / COE / MEM

校准默认同时导出 signed-two's-complement `Q4.12`：审计 CSV、Xilinx `.coe` 与每行一个十六进制字的 `.mem`。默认地址为幅值主序 `amplitude_index * frequency_count + frequency_index`，默认越界报错，不静默截断。

```toml
[steps.calibration.fixed_point]
word_width = 16
fractional_bits = 12
formats = ["csv", "coe", "mem"]
layout = "amplitude_major" # 或 frequency_major
rounding = "nearest"
overflow = "error"         # 需要硬件饱和时才显式使用 saturate
```

### 拟合方法

除专供二维校准的模型外，传统线性增益拟合仍使用因变量 `gain_linear` 与 `x = log10(f / Hz)`：

- `linear_log`：分段线性插值，导出每段 `m`、`b`，即 `G = m*x + b`。
- `polynomial`：1–5 阶多项式，导出降幂系数。阶数必须小于有效频点数。
- `pchip`：保形三次插值，导出每段 `x_start`、`x_stop` 和 `[c3, c2, c1, c0]`，即 `G = c3*dx^3 + c2*dx^2 + c1*dx + c0`。它需要先安装 `python -m pip install -e ".[analysis]"`。
- `smoothing_spline_db`：在 dB 增益域对 `log10(f / Hz)` 做平滑样条，输出曲线用于可读性更好的报告和调试；少于四个有效点时标为 unavailable。
- `piecewise_chebyshev_db`：在 dB 域给出低阶分段 Chebyshev 近似，适合需要直接计算公式的调试后端。

二维校准固定使用 `smoothing_spline_db`；它会用规律留点交叉验证在若干平滑度候选中选择一个全切片共享的惩罚，再导出每幅值的三阶、默认 8 个对数频段的 Chebyshev 系数。校正定义为 `correction_db = target_gain_db - fitted_gain_db`，线性乘数为 `10^(correction_db / 20)`；补偿幅度和相邻频点的 dB/oct 斜率都会被限制并逐点标记。

相位使用输出相对输入的相量差，CSV 同时提供 `phase_wrapped_deg` 和不跨失败点连接的 `phase_unwrapped_deg`。探头、电缆和通道延迟均会包含在相位里；先做直通基线或 deskew，才能把相位解释为 DUT 本体特性。

## 一个 step 只做一件事

例如设置电源电压不会顺手打开输出：

```toml
[[steps]]
kind = "power.set"
channel = 1
voltage_v = 3.3
current_limit_a = 0.1
```

如果要开关输出，必须另写：

```toml
[[steps]]
kind = "power.output"
channel = 1
state = "on"
```

这看起来啰嗦，但它能避免现场调试时被隐藏动作吓到。

### Source V2 基础、高级配置与 ARB 写 step

声明 `source.snapshot_v2` 与对应写 capability 的插件可以使用 Source V2 step。基础配置只在目标输出已关闭时执行；输出 ON 与 OFF 分别使用不同 step：

```toml
[[steps]]
kind = "source.basic_configure_v2"
channel = 1
waveform_kind = "sine"
frequency_hz = 1000
amplitude_vpp = 1.0
offset_v = 0.0

[[steps]]
kind = "source.output_enable_v2"
channel = 1

[[steps]]
kind = "source.output_disable_v2"
channel = 1

[[steps]]
kind = "source.counter_configure_v2"
input_id = "counter"
coupling = "ac"

[[steps]]
kind = "source.counter_enable_v2"
input_id = "counter"

[[steps]]
kind = "source.counter_measure_v2"
input_id = "counter"

[[steps]]
kind = "source.counter_disable_v2"
input_id = "counter"

[[steps]]
kind = "source.harmonics_configure_v2"
channel = 1
order = 8
preset = "odd"

[[steps]]
kind = "source.harmonics_disable_v2"
channel = 1

[[steps]]
kind = "source.modulation_configure_v2"
channel = 1
depth_percent = 80
internal_frequency_hz = 25

[[steps]]
kind = "source.modulation_pm_configure_v2"
channel = 1
phase_deviation_deg = 90
internal_frequency_hz = 25

[[steps]]
kind = "source.modulation_fm_configure_v2"
channel = 1
frequency_deviation_hz = 12500
internal_frequency_hz = 25

[[steps]]
kind = "source.modulation_pwm_configure_v2"
channel = 1
internal_frequency_hz = 25
duty_deviation_percent = 30

[[steps]]
kind = "source.sweep_configure_v2"
channel = 1
start_hz = 100
stop_hz = 1000
spacing = "linear"
steps = 101
sweep_time_s = 1

[[steps]]
kind = "source.burst_configure_v2"
channel = 1
cycles = 12
phase_deg = 30
internal_period_s = 0.25
delay_s = 0.5

[[steps]]
kind = "source.pulse_configure_v2"
channel = 1
width_s = 1e-6
delay_s = 0
leading_transition_s = 1e-8
trailing_transition_s = 1e-8

[[steps]]
kind = "source.arbitrary_storage_v2"
channel = 1
slot_id = "slot_a"
file = "payload.bin"
write_mode = "create_only"

[[steps]]
kind = "source.arbitrary_select_v2"
channel = 1
slot_id = "slot_a"
playback_mode = "dds"
playback_frequency_hz = 1000

[[steps]]
kind = "source.combine_configure_v2"
channels = [1, 2]
enabled = true
```

`source.basic_configure_v2` 的 `channel` 必填，五个 basic 字段中至少写一个；缺失字段保持当前值。
`source.output_enable_v2`、`source.output_disable_v2` 和 `source.harmonics_disable_v2` 都只接受 `channel`。`source.harmonics_configure_v2`
要求 `channel`、整数 `order >= 2` 与 `all`、`even`、`odd` 之一的 `preset`；核心还会在执行前检查运行时
profile 是否支持该 order 和预设。`source.modulation_configure_v2` 要求 `channel`、位于 `[0, 100]` 的
`depth_percent` 与有限正值 `internal_frequency_hz`；它只配置内部正弦 AM。
`source.counter_configure_v2` 要求安全 token 形式的 `input_id`，并在 coupling、
`impedance_ohm`、`attenuation`、`trigger_level_v` 与 `statistics_enabled` 中恰好指定一个字段。
它不启用 Counter。`source.counter_enable_v2` 与 `source.counter_disable_v2` 只接受 `input_id`，
不隐式改写输入配置；`source.counter_measure_v2` 也只接受 `input_id`，要求 Counter 已启用。
Counter 测量 artifact 位于该 step 的 `counter_measurement`，不进入 `source_operations`。实际信号、
输入阻抗与最大 Vpp 仍必须由计划 safety 和接线确认；Counter step 不替代输出安全门。
`source.modulation_pm_configure_v2` 要求 `channel`、位于 `[0, 360]` 的 `phase_deviation_deg` 与有限正值
`internal_frequency_hz`；它只配置内部正弦 PM。
`source.modulation_fm_configure_v2` 要求 `channel`、有限正值 `frequency_deviation_hz` 与有限正值
`internal_frequency_hz`；它只配置内部正弦 FM。
`source.modulation_pwm_configure_v2` 要求 `channel`、有限正值 `internal_frequency_hz`，以及恰好一个显式单位分支：
位于 `[0, 50]` 的 `duty_deviation_percent` 或位于 `[0, 500000]` 秒的 `width_deviation_s`；它只配置内部正弦 PWM。
`source.sweep_configure_v2` 要求 `channel`、有限正值且 start 不大于 stop 的 `start_hz`／`stop_hz`、`linear`、
`logarithmic`、`step` 之一的 `spacing`、位于 `[2, 2048]` 的整数 `steps` 与位于 `[0.001, 300]` 秒的 `sweep_time_s`；
它只配置内建 Sweep，不会 fire 或开启输出。
`source.burst_configure_v2` 要求 `channel`、位于 `[1, 500000]` 的整数 `cycles`、位于 `[0, 360]` 的
`phase_deg`、有限正值 `internal_period_s` 与位于 `[0, 85]` 的 `delay_s`；它只配置内部 Triggered Burst，
不会 trigger 或开启输出。
`source.pulse_configure_v2` 要求 `channel`、不小于 `4 ns` 的 `width_s`、有限非负 `delay_s`，以及有限正值
`leading_transition_s`／`trailing_transition_s`；两个 transition 都不能超过 width 的 `0.625` 倍，且它只配置 WIDTH 脉冲形状。

`source.arbitrary_storage_v2` 要求 `channel`、安全 token 形式的 `slot_id`、相对或绝对的 `file`，以及
`create_only` 或 `replace_if_digest_matches` 的 `write_mode`。replace mode 还必须给出
`expected_previous_sha256`。执行时会从 plan 所在目录解析相对文件，计算 payload 的 SHA-256 和大小；这些字节不会
写入执行意图或 Source operation artifact。storage 不选择波形、不改变输出，目标或其它独立端口不需要因上传被关闭。

`source.arbitrary_select_v2` 要求 `channel`、`slot_id` 与 `dds`／`true_arb` 之一的 `playback_mode`。DDS 只接受
正的 `playback_frequency_hz`；true-ARB 只接受正的 `sample_rate_hz`。该 step 必须在目标输出已关闭时执行，完成后仍关闭；
它不包含 output ON。

`source.combine_configure_v2`、`source.coupling_configure_v2`、`source.tracking_configure_v2` 和
`source.phase_relation_configure_v2` 都要求递增且唯一的 `channels` 数组（至少两个通道）与布尔 `enabled`。核心按
descriptor relation graph 展开实际受影响端口；只有展开后的端口必须 OFF，未连通端口可以继续 ON。它们不会开启输出、
不会设置厂商私有关系参数，也不会为之后的 output ON 提供额外授权。

Harmonic、内部 AM、内部 PM、内部 FM、内部 PWM、内部 Sweep、内部 Triggered Burst 与 WIDTH Pulse step 都必须在目标输出已关闭时执行，完成后仍保持关闭；它们不会隐式开启输出。现有
`restore.source_state` 只恢复 basic 状态，不恢复 Harmonic、调制、Burst 或 Pulse 配置。双合同插件声明
`source.harmonics_configure_v2` 或 `source.harmonics_disable_v2` 后，V1 `configure_harmonics` 会在仪器 I/O 前被拒绝；声明
`source.modulation_configure_v2` 后，V1 `configure_am_modulation` 会在仪器 I/O 前被拒绝。未声明对应能力的
旧插件继续使用 V1 路径。声明 `source.modulation_pm_configure_v2` 后，V1 `configure_pm_modulation` 也会在
仪器 I/O 前被拒绝。声明 `source.modulation_fm_configure_v2` 后，V1 `configure_fm_modulation` 和 restore 也会在
仪器 I/O 前被拒绝。声明 `source.modulation_pwm_configure_v2` 后，V1 `configure_pwm_modulation` 和 restore 也会在
仪器 I/O 前被拒绝。声明 `source.sweep_configure_v2` 后，V1 `configure_sweep`、`trigger_sweep` 和 restore 也会在
仪器 I/O 前被拒绝。声明 `source.burst_configure_v2` 后，V1 `configure_burst`、`trigger_burst` 和 restore 也会在
仪器 I/O 前被拒绝。声明 `source.pulse_configure_v2` 后，V1 `configure_pulse` 也会在仪器 I/O 前被拒绝，
因为 V1 route 还允许 DUTY hold。该 step 不会让 `source.output_enable_v2` 获得 Pulse 输出 ON 授权。

声明 `source.coupling_configure_v2` 后，V1 `configure_coupling` 在仪器 I/O 前拒绝；声明任一跨通道 V2 capability
后，V1 restore 也会在仪器 I/O 前拒绝，避免它在未知 relation state 下重开输出。

执行意图会记录十八个 Source V2 operation，实际执行时的完整 Source V2 artifact 会写入
`run.json.source_operations`；storage payload 只以文件名、SHA-256 与大小出现。没有声明 V2 capability 的旧插件继续使用 V1 step。

## 常见 `run check` 报错

### step kind 拼错

错误 plan：

```toml
[[steps]]
kind = "scope.captur"
```

输出类似：

```text
wavebench: steps[0].kind 'scope.captur' is not supported. Did you mean 'scope.capture'? Supported kinds: ... Run `python -m wavebench run schema` for field details.
```

修法：改成 `scope.capture`，或先运行 `run schema` 查看支持列表。

### 字段名拼错

错误 plan：

```toml
[[steps]]
kind = "sleep"
duraton_s = 0.5
```

输出类似：

```text
wavebench: steps[0] has unknown key(s): duraton_s. Did you mean 'duraton_s' -> 'duration_s'? Allowed keys: duration_s, kind. Run `python -m wavebench run schema` for field details.
```

修法：改成 `duration_s`。

### 缺少必填字段

错误 plan：

```toml
[[steps]]
kind = "power.set"
voltage_v = 3.3
```

输出类似：

```text
wavebench: steps[0] power.set missing required field 'current_limit_a'. Required fields: voltage_v, current_limit_a. Optional fields: channel. Run `python -m wavebench run schema` for examples.
```

修法：补上 `current_limit_a`。

## `scope.capture` 的质量检查和断言

`scope.capture` 默认只采集。需要截图、质量检查或断言时都要显式写：

```toml
[[steps]]
kind = "scope.capture"
channel = 1
label = "duty_50"
window_frequency_hz = 10000
target_cycles = 10
screenshot = true
quality_gate = true
auto_recover = true

[steps.expect]
frequency_estimate_hz = { min = 9500, max = 10500 }
duty_cycle = { min = 0.45, max = 0.55 }
voltage_vpp_v = { min = 2.8, max = 3.8 }
```

含义：

- `screenshot = true`：本次采集额外保存 `screenshot.png`，并在 `metadata.json.files.screenshot` 记录路径；截图失败不会吞掉波形包。
- `quality_gate = true`：把采集质量状态写入 `run.json` / `summary.csv`。
- `auto_recover = true`：如果质量有 warning，显式执行 `scope.auto` 并重采，最多次数由 `[quality].auto_recover_attempts` 控制。
- `[steps.expect]`：对采集摘要指标做 min/max 断言。断言失败时当前 step 标记为 `failed`，默认停止后续步骤，但采集包仍保留。

### 失败策略和安全门

所有 step 都支持 `on_failure`，默认值是 `"stop"`。需要在失败后继续执行后续步骤时，必须显式写出：

```toml
[[steps]]
kind = "scope.capture"
on_failure = "continue"
```

`quality_gate = true` 且采集仍有 warning 时，step 会标记为 `failed`；`quality_gate` 未启用时，普通质量 warning 不会单独停止 run。频响 step 的点级采集失败仍会保留 CSV 行，并按 `stop_conditions` 决定是否结束当前频响 step。

安全门独立于 `on_failure`。计划级安全门需要明确授权 OFF 通道：

```toml
[safety]
safety_gate = true
off_source_channels = [1]
off_power_channels = [1]
```

安全门遇到失败或 gate warning 时，先对授权通道执行 OFF，再停止 run；`on_failure = "continue"` 不会覆盖这个停止动作。若启用 source restore，恢复配置后会再次确认授权通道为 OFF。关断结果会写入失败 step 的 `artifact.safety_gate` 和顶层 `run.json.error`。未列出任何 OFF 目标时，执行器会把安全门视为配置失败，不会猜测其他通道。

## run 输出字段契约

`run plan` 会生成：

```text
data/runs/YYYYMMDD_HHMMSS_<label>/
  plan.toml
  run.json
  summary.csv
  steps/
    00_<kind>.json
    01_<kind>.json
```

### `run.json`

稳定字段：

| 字段 | 含义 |
|---|---|
| `status` | 整个 run 的状态，常见值：`ok`、`failed`。 |
| `plan` | plan 路径、实验名、label 等摘要。 |
| `safety` | safety guard 的检查结果；未启用时为空或简短状态。 |
| `restore` | source restore 的 snapshot / restore 状态；未启用时为空或简短状态。 |
| `steps` | 每个 step 的执行记录。 |
| `error` | run 级失败信息；例如 `code = "step_failed"` 或 `code = "safety_gate_failed"`。 |
| `source_operations` | 实际执行的 Source V2 operation artifact；没有 Source V2 step 时不存在。 |

`steps[]` 常见字段：

| 字段 | 含义 |
|---|---|
| `index` | step 序号。 |
| `kind` | step kind，例如 `scope.capture`。 |
| `status` | step 状态，常见值：`ok`、`failed`。 |
| `artifact` | 该 step 产生的结构化结果。 |
| `error` | 失败时的错误类型和消息。 |

`scope.capture` 的 `artifact` 常见字段：

| 字段 | 含义 |
|---|---|
| `package` | 普通采集包路径。 |
| `metadata` | 采集包 `metadata.json` 路径。 |
| `quality` | 质量摘要，含 `status`、warnings 和关键测量指标。 |
| `quality_recovery` | 自动恢复尝试记录；未启用或未触发时可能不存在。 |
| `expect` | `[steps.expect]` 的检查结果；未配置时可能不存在。 |
| `safety_gate` | 安全门的授权 OFF 通道、执行动作和失败原因；仅在安全门触发时存在。 |

`sweep.frequency_response` 的 `artifact.frequency_response` 常见字段：

| 字段 | 含义 |
|---|---|
| `csv` | 此 response 的逐点 `frequency_response.csv`；多 response 时在独立子目录。 |
| `fit_json` | 启用拟合时的 `frequency_response_fit.json`；未启用则为空。 |
| `calibration_csv` / `calibration_json` | 自动二维校准成功时的派生 LUT 路径；未启用或未生成则为空。 |
| `baseline_json` | 软件基线引用、模式、有效域和估算延迟；未配置则为空。 |
| `adaptive` | 初始/最终频点数、层数、预算限制和配置；未配置则不存在。 |
| `fixed_point` | 定点 audit CSV/COE/MEM 路径；校准未生成时为空对象。 |
| `calibration_error` | 自动校准未生成时的原因；原始频响仍然保留。 |
| `captures` | 每个已有双通道采集包与 metadata 的引用，供报告和审计使用。 |
| `evidence` | 证据 schema、计划哈希、参考平面、同步等级、`case_id` 和 `acquisition_id` 列表。 |
| `resume` | 使用 `resume_from` 时的来源 CSV、复用点数、待补测点数和拒绝原因。 |
| `stop_conditions` / `stop_reason` | 显式组停止条件和触发原因；未配置时不存在。 |
| `failed_point_count` / `warning_point_count` | 频点失败与质量 warning 数量。 |

### `summary.csv`

`summary.csv` 面向脚本和表格查看。常见列：

| 列 | 含义 |
|---|---|
| `step_index` | step 序号。 |
| `kind` | step kind。 |
| `status` | step 状态。 |
| `package` | scope capture 产生的采集包路径。 |
| `metadata` | 对应 `metadata.json` 路径。 |
| `quality_status` | 质量状态，例如 `ok`、`warning`、`ok_by_consistency`。 |
| `quality_warnings` | 质量 warning 摘要。 |
| `expect_status` | 断言状态，例如 `ok`、`failed`。 |
| `expect_failures` | 断言失败原因摘要。 |

后续分析脚本应优先读取 `run.json`。`summary.csv` 适合快速查看和导入表格软件。

## 生成离线报告

跑完 run 后，用：

```powershell
python -m wavebench run report data/runs/<run_dir>
```

`run report` 只读已有 `run.json`、`summary.csv`、采集包 `metadata.json`、`ch*.npy` 和截图，不连接仪器，也不修改原始采集数据。

HTML 报告当前会汇总：

- `摘要 / Summary`：run 状态、失败步骤、采集数量、警告、恢复状态、主频率和主 Vpp。
- `实验证据摘要 / Run evidence summary`：source 步骤、scope capture、DMM 读数、`run.json`、`summary.csv`、截图和波形预览数量。
- `证据时间线 / Evidence timeline`：按 step 展示 source/scope/DMM/sleep 的证据摘要。
- `扫频摘要 / Sweep summary`：当 run 里有多点 `scope.capture` 或 sweep label 时显示，列出每个频点的 label、status、quality、expect、FFT、frequency、Vpp、FFT peak、peak amplitude 和 THD。
- `频率响应 / Frequency response`：按每个 manifest response 显示原始/软件校正幅频和相频、基线与自适应摘要、拟合对比、逐点表格、拟合公式/参数和原始采集包链接；校准产物还会显示目标、留点验证误差、补偿热图、代表性幅值切片和定点摘要。安装 `.[report3d]` 后，至少 2 个 Vpp × 2 个频率节点的 response 会在 Bode 图前增加交互式三维增益曲面，可切换 Raw/Corrected、dB/V/V，并查看 warning、自动恢复次数和采集证据。
- `验收摘要 / Acceptance summary` 与 `预期 vs 实测 / Expected vs measured`：汇总 `[steps.expect]` 和 `[steps.expect_fft]` 的验收结果。
- `DMM 读数 / DMM readings`、`信号分析 / Signal analysis`、`波形预览 / Waveform previews`、`截图 / Screenshots`。

安装 `.[pdf]` 后可在同一离线命令中导出 PDF：

```powershell
python -m wavebench run report data/runs/<run_dir> --pdf
python -m wavebench run report data/runs/<run_dir> --output reports/lowpass.html --pdf --pdf-output reports/lowpass.pdf
```

PDF 会嵌入 HTML 中可见的截图、静态 SVG 曲线和表格，适合把报告发给他人或归档。CSV、拟合 JSON、NPY 和完整采集包仍是独立证据文件；PDF 中保留它们的链接，但不把大型原始波形伪装成可见图表。WeasyPrint 还需要操作系统提供 Cairo、Pango、GDK-PixBuf 和合适的中文字体。

三维 HTML 使用报告目录内的 `report-assets/plotly.min.js`，不访问 CDN；移动或打包 HTML 时必须同时保留整个 `report-assets/`。failed 点在曲面中保持空洞，不插值补齐；单幅值或不足 2 × 2 的数据自动退回静态 Bode。PDF 的 compact 渲染路径不加载 Plotly，也不预留空白交互区域，因此仍是单文件静态归档。

典型 sweep 流程：

```powershell
python -m wavebench run template source-scope-sweep --frequencies 100,1000,10000 --output plans/source_scope_sweep.toml
python -m wavebench run check  --config wavebench.toml --plan plans/source_scope_sweep.toml
python -m wavebench run verify --config wavebench.toml --plan plans/source_scope_sweep.toml
python -m wavebench run plan   --config wavebench.toml --plan plans/source_scope_sweep.toml
python -m wavebench run report data/runs/<run_dir>
```

## 现场写 plan 的顺序

建议按这个顺序来：

1. 先写 `[experiment]` 和必要的 `[safety]` / `[restore]`。
2. 每次只加 1~2 个 `[[steps]]`。
3. 运行 `run check`。
4. 确认摘要里没有隐藏动作。
5. 接上仪器后再运行 `run plan`。
6. 跑完先看 `run.json.status` 和 `summary.csv`，再看具体采集包。

别急着写很聪明的流程。电赛现场，朴素的记录更可靠。
