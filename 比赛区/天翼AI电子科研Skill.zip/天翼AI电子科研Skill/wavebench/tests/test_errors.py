from __future__ import annotations

import json

from wavebench.errors import (
    ERROR_SCHEMA,
    ConfigError,
    ErrorEnvelope,
    InstrumentError,
    SessionCloseError,
    SessionHealthError,
    SourceSafetyLimitsRequiredError,
    TransportIOError,
    error_envelope,
    ensure_error_envelope,
)
from wavebench.transport.contracts import (
    CommandTransmission,
    ReplayPolicy,
    ResponseProgress,
    Synchronization,
    TransportPhase,
)


def test_wavebench_error_keeps_numeric_exit_code_and_adds_stable_code() -> None:
    error = ConfigError("bad plan")

    payload = error.to_envelope(operation="run.check", details={"step": 2}).as_dict()

    assert payload == {
        "schema": ERROR_SCHEMA,
        "code": "config_error",
        "type": "ConfigError",
        "message": "bad plan",
        "exit_code": 2,
        "operation": "run.check",
        "details": {"step": 2},
    }


def test_error_envelope_serializes_nested_cause_without_traceback() -> None:
    payload = error_envelope(
        InstrumentError("write failed"),
        operation="source.output",
        cause=ConfigError("source is missing"),
    )

    assert payload["code"] == "instrument_error"
    assert payload["cause"]["code"] == "config_error"
    assert "traceback" not in payload["cause"]


def test_keyboard_interrupt_has_shell_compatible_exit_code() -> None:
    payload = error_envelope(KeyboardInterrupt())

    assert payload["code"] == "interrupted"
    assert payload["type"] == "KeyboardInterrupt"
    assert payload["exit_code"] == 130


def test_error_envelope_is_json_compatible() -> None:
    payload = ErrorEnvelope(
        code="custom",
        message="message",
        exit_code=7,
        error_type="CustomError",
    ).as_dict()
    assert payload["schema"] == ERROR_SCHEMA


def test_source_safety_limits_required_error_has_stable_sorted_fields() -> None:
    error = SourceSafetyLimitsRequiredError(
        ("min_source_port_voltage_v", "max_source_vpp", "min_source_port_voltage_v")
    )

    payload = error.to_envelope(operation="source.output_v2").as_dict()

    assert payload["code"] == "source_safety_limits_required"
    assert payload["details"] == {
        "missing_fields": ["max_source_vpp", "min_source_port_voltage_v"],
    }


def test_session_health_error_is_zero_io_and_does_not_serialize_reason_or_cause() -> None:
    error = SessionHealthError(
        "blocked: SECRET:VALUE",
        health="poisoned",
        io_kind="query",
        epoch_id="epoch-1",
    )
    payload = error.to_envelope(
        operation="scope.fetch",
        cause=RuntimeError("backend payload SECRET"),
    ).as_dict()

    assert payload["code"] == "session_health_error"
    assert "SECRET" not in payload["message"]
    assert payload["details"] == {
        "session_health": "poisoned",
        "io_kind": "query",
        "command_transmission": "not_sent",
        "response_progress": "none",
        "synchronization": "proven",
        "attempts": 0,
        "epoch_id": "epoch-1",
    }
    assert "cause" not in payload
    assert json.loads(json.dumps(payload)) == payload


def test_session_health_error_drops_caller_details() -> None:
    payload = error_envelope(
        SessionHealthError(
            "ignored",
            health="uncertain",
            io_kind="query",
            epoch_id="epoch-2",
        ),
        details={"command": "SECRET", "resource": "/private/device"},
    )

    assert "command" not in payload["details"]
    assert "resource" not in payload["details"]


def test_transport_error_sanitizes_mapping_cause_tokens() -> None:
    error = TransportIOError(
        "query failed",
        operation="query",
        phase=TransportPhase.READING,
        replay_policy=ReplayPolicy.NO_REPLAY,
        command_transmission=CommandTransmission.SENT,
        response_progress=ResponseProgress.UNKNOWN,
        synchronization=Synchronization.UNPROVEN,
        attempts=1,
    )

    payload = error_envelope(
        error,
        cause={"type": "SECRET command payload", "code": "bad code with spaces"},
    )

    assert payload["cause"] == {"type": "BackendError", "code": "backend_error"}


def test_session_close_error_exposes_only_component_and_exception_type() -> None:
    error = SessionCloseError(
        [
            ("session", RuntimeError("SECRET resource TCPIP::private")),
            ("resource_manager", OSError("/private/path")),
        ]
    )

    payload = error_envelope(error, operation="session.close.scope")

    assert payload["code"] == "session_close_failed"
    assert payload["details"] == {
        "failed_components": [
            {"component": "session", "type": "RuntimeError"},
            {"component": "resource_manager", "type": "OSError"},
        ]
    }
    assert "SECRET" not in json.dumps(payload)
    assert "/private/path" not in json.dumps(payload)


def test_legacy_error_mapping_is_augmented_without_dropping_custom_fields() -> None:
    payload = ensure_error_envelope(
        {"type": "StepFailure", "message": "failed", "step_index": 3},
        default_code="step_failed",
        default_exit_code=2,
    )

    assert payload["schema"] == ERROR_SCHEMA
    assert payload["code"] == "step_failed"
    assert payload["exit_code"] == 2
    assert payload["step_index"] == 3
