from __future__ import annotations

import json
from contextlib import nullcontext
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from types import SimpleNamespace

import pytest

from wavebench.errors import ConfigError, StateDriftError
from wavebench.logging import CommandLogger
from wavebench.services.run_analysis import step_status
from wavebench.services.run_artifacts import RunStepRecord
from wavebench.services.run_plan import load_run_plan
from wavebench.services.run_service import RunInstrumentServices, RunService


def _write_plan(tmp: str, content: str) -> Path:
    path = Path(tmp) / "plan.toml"
    path.write_text(content, encoding="utf-8")
    return path


def _service(tmp: str) -> RunService:
    # The loop tests use sleep-only plans, so no instrument configuration is needed.
    from test_run_service import make_config

    return RunService(config=make_config(tmp), logger=CommandLogger())


def _record(step_index: int, kind: str, status: str) -> RunStepRecord:
    return RunStepRecord(
        index=step_index,
        kind=kind,
        status=status,
        fields={},
        artifact={"test_status": status},
    )


def test_failed_step_stops_by_default_and_writes_stop_reason() -> None:
    with TemporaryDirectory() as tmp:
        plan = load_run_plan(
            _write_plan(
                tmp,
                """
[[steps]]
kind = "sleep"
duration_s = 0.01

[[steps]]
kind = "sleep"
duration_s = 0.01
""",
            )
        )
        service = _service(tmp)
        calls: list[int] = []

        def run_step(_plan, step, **_kwargs):
            calls.append(step.index)
            return _record(step.index, step.kind, "failed" if step.index == 0 else "ok")

        with patch.object(service, "_run_step", side_effect=run_step):
            result = service.run(plan)

        assert calls == [0]
        assert [record.status for record in result.steps] == ["failed"]
        run_data = json.loads(result.run_json_path.read_text(encoding="utf-8"))
        assert run_data["status"] == "failed"
        assert run_data["error"]["schema"] == "wavebench.error.v1"
        assert run_data["error"]["exit_code"] == 2
        assert run_data["error"]["code"] == "step_failed"
        assert run_data["error"]["type"] == "StepFailure"
        assert run_data["error"]["message"] == "run step 0 (sleep) failed"
        assert run_data["error"]["step_index"] == 0
        assert run_data["error"]["step_kind"] == "sleep"
        assert run_data["error"]["policy"] == "stop"


def test_failed_step_can_explicitly_continue() -> None:
    with TemporaryDirectory() as tmp:
        plan = load_run_plan(
            _write_plan(
                tmp,
                """
[[steps]]
kind = "sleep"
duration_s = 0.01
on_failure = "continue"

[[steps]]
kind = "sleep"
duration_s = 0.01
""",
            )
        )
        assert plan.steps[0].fields["on_failure"] == "continue"
        service = _service(tmp)
        calls: list[int] = []

        def run_step(_plan, step, **_kwargs):
            calls.append(step.index)
            return _record(step.index, step.kind, "failed" if step.index == 0 else "ok")

        with patch.object(service, "_run_step", side_effect=run_step):
            result = service.run(plan)

        assert calls == [0, 1]
        assert [record.status for record in result.steps] == ["failed", "ok"]
        run_data = json.loads(result.run_json_path.read_text(encoding="utf-8"))
        assert run_data["status"] == "failed"
        assert "error" not in run_data


def test_run_artifact_records_native_instrument_io_counters() -> None:
    with TemporaryDirectory() as tmp:
        plan = load_run_plan(
            _write_plan(
                tmp,
                """
[[steps]]
kind = "sleep"
duration_s = 0.01
""",
            )
        )
        service = _service(tmp)
        audited = SimpleNamespace(
            audit_snapshot=lambda: {
                "schema": "wavebench.instrument_io.v1",
                "access": "read_only",
                "counters": {
                    "instrument_mutation_writes": 0,
                    "instrument_mutation_writes_completed": 0,
                },
            }
        )
        services = RunInstrumentServices(source=audited)  # type: ignore[arg-type]

        with patch.object(
            service, "_run_instrument_services", return_value=nullcontext(services)
        ):
            result = service.run(plan)

        run_data = json.loads(result.run_json_path.read_text(encoding="utf-8"))
        instrument_io = run_data["provenance"]["instrument_io"]
        assert instrument_io["schema"] == "wavebench.run_instrument_io.v1"
        assert instrument_io["instrument_mutation_writes"] == 0
        assert instrument_io["instruments"]["source"]["access"] == "read_only"


def test_state_drift_error_keeps_structured_details_in_run_artifact() -> None:
    with TemporaryDirectory() as tmp:
        plan = load_run_plan(
            _write_plan(
                tmp,
                """
[[steps]]
kind = "sleep"
duration_s = 0.01
""",
            )
        )
        service = _service(tmp)
        failure = StateDriftError(
            "source channel 1 changed outside the current run; refusing write",
            expected={"channel": 1, "frequency_hz": 1000.0},
            actual={"channel": 1, "frequency_hz": 2000.0},
            diff={
                "frequency_hz": {
                    "expected": 1000.0,
                    "actual": 2000.0,
                }
            },
        )
        with patch.object(service, "_run_step", side_effect=failure):
            with pytest.raises(StateDriftError):
                service.run(plan)

        run_dir = next((Path(tmp) / "data" / "runs").iterdir())
        run_data = json.loads((run_dir / "run.json").read_text(encoding="utf-8"))
        assert run_data["error"]["schema"] == "wavebench.error.v1"
        assert run_data["error"]["code"] == "state_drift"
        assert run_data["error"]["details"]["diff"]["frequency_hz"]["actual"] == 2000.0


def test_run_artifact_records_state_guard_provenance() -> None:
    with TemporaryDirectory() as tmp:
        plan = load_run_plan(
            _write_plan(
                tmp,
                """
[[steps]]
kind = "sleep"
duration_s = 0.01
""",
            )
        )
        service = _service(tmp)
        guarded = SimpleNamespace(
            state_guard_snapshot=lambda: {"1": {"channel": 1, "output": "OFF"}}
        )
        services = RunInstrumentServices(source=guarded)  # type: ignore[arg-type]

        with patch.object(
            service, "_run_instrument_services", return_value=nullcontext(services)
        ):
            result = service.run(plan)

        run_data = json.loads(result.run_json_path.read_text(encoding="utf-8"))
        state_guard = run_data["provenance"]["state_guard"]
        assert state_guard["schema"] == "wavebench.state_guard.v1"
        assert state_guard["expected"]["source"]["1"]["output"] == "OFF"


def test_on_failure_rejects_unknown_policy() -> None:
    with TemporaryDirectory() as tmp:
        plan_path = _write_plan(
            tmp,
            """
[[steps]]
kind = "sleep"
duration_s = 0.01
on_failure = "ask"
""",
        )
        with pytest.raises(ConfigError, match="on_failure must be 'stop' or 'continue'"):
            load_run_plan(plan_path)


def test_quality_gate_warning_is_a_failed_step() -> None:
    assert step_status({"quality_gate": {"status": "warning"}}) == "failed"
    assert step_status({"quality": {"status": "warning"}}) == "ok"


def test_safety_gate_turns_off_authorized_outputs_before_stopping() -> None:
    with TemporaryDirectory() as tmp:
        plan = load_run_plan(
            _write_plan(
                tmp,
                """
[safety]
safety_gate = true
off_source_channels = [1]
off_power_channels = [2]

[[steps]]
kind = "sleep"
duration_s = 0.01
on_failure = "continue"

[[steps]]
kind = "sleep"
duration_s = 0.01
""",
            )
        )
        service = _service(tmp)
        source = patch("wavebench.services.run_service.SourceService").start()
        power = patch("wavebench.services.run_service.PowerService").start()
        try:
            source_instance = source.return_value
            source_instance.set_output.return_value = SimpleNamespace(output="OFF")
            power_instance = power.return_value
            power_instance.set_output.return_value = SimpleNamespace(output="OFF")
            services = RunInstrumentServices(source=source_instance, power=power_instance)
            calls: list[int] = []

            def run_step(_plan, step, **_kwargs):
                calls.append(step.index)
                return _record(step.index, step.kind, "failed" if step.index == 0 else "ok")

            with patch.object(service, "check"), patch.object(
                service, "_run_instrument_services", return_value=nullcontext(services)
            ), patch.object(service, "_run_step", side_effect=run_step):
                result = service.run(plan)

            assert calls == [0]
            source_instance.set_output.assert_called_once_with(channel=1, enabled=False)
            power_instance.set_output.assert_called_once_with(channel=2, enabled=False)
            run_data = json.loads(result.run_json_path.read_text(encoding="utf-8"))
            assert run_data["error"]["code"] == "safety_gate_failed"
            assert run_data["steps"][0]["artifact"]["safety_gate"]["status"] == "ok"
        finally:
            patch.stopall()


def test_step_safety_gate_can_infer_source_channel_and_capture_gate_failure() -> None:
    with TemporaryDirectory() as tmp:
        plan = load_run_plan(
            _write_plan(
                tmp,
                """
[[steps]]
kind = "source.set_freq"
channel = 3
frequency_hz = 1000
safety_gate = true
""",
            )
        )
        service = _service(tmp)
        source = patch("wavebench.services.run_service.SourceService").start()
        try:
            source_instance = source.return_value
            source_instance.set_output.side_effect = ConfigError("OFF failed")
            services = RunInstrumentServices(source=source_instance)
            with patch.object(service, "check"), patch.object(
                service, "_run_instrument_services", return_value=nullcontext(services)
            ), patch.object(
                service,
                "_run_step",
                return_value=_record(0, "source.set_freq", "failed"),
            ):
                result = service.run(plan)

            source_instance.set_output.assert_called_once_with(channel=3, enabled=False)
            run_data = json.loads(result.run_json_path.read_text(encoding="utf-8"))
            assert run_data["error"]["code"] == "safety_gate_failed"
            assert run_data["error"]["safety_gate"]["status"] == "failed"
            assert run_data["error"]["safety_gate"]["errors"][0]["message"] == "OFF failed"
        finally:
            patch.stopall()


def test_safety_gate_plan_fields_are_normalized() -> None:
    with TemporaryDirectory() as tmp:
        plan = load_run_plan(
            _write_plan(
                tmp,
                """
[safety]
safety_gate = true
off_source_channels = [1, 2]
off_power_channels = 3

[[steps]]
kind = "sleep"
duration_s = 0.01
safety_gate = { source_channels = [4], power_channels = [5] }
""",
            )
        )
        assert plan.safety.safety_gate is True
        assert plan.safety.off_source_channels == (1, 2)
        assert plan.safety.off_power_channels == (3,)
        assert plan.steps[0].fields["safety_gate"] == {
            "enabled": True,
            "source_channels": [4],
            "power_channels": [5],
        }


def test_safety_gate_remains_off_after_source_restore() -> None:
    with TemporaryDirectory() as tmp:
        plan = load_run_plan(
            _write_plan(
                tmp,
                """
[restore]
source_state = true
source_channel = 1

[[steps]]
kind = "source.set_freq"
channel = 1
frequency_hz = 1000
safety_gate = true
""",
            )
        )
        service = _service(tmp)
        source = patch("wavebench.services.run_service.SourceService").start()
        try:
            source_instance = source.return_value
            from wavebench.services.source_state import RestorableSourceState
            state = RestorableSourceState(1, "ON", "SIN", 1000., 1., "VPP")
            source_instance.snapshot_restorable_state.return_value = state
            source_instance.restore_restorable_state.return_value = SimpleNamespace(output="ON")
            source_instance.set_output.return_value = SimpleNamespace(output="OFF")
            services = RunInstrumentServices(source=source_instance)
            with patch.object(service, "check"), patch.object(
                service, "_run_instrument_services", return_value=nullcontext(services)
            ), patch.object(
                service,
                "_run_step",
                return_value=_record(0, "source.set_freq", "failed"),
            ):
                result = service.run(plan)

            assert source_instance.restore_restorable_state.call_count == 1
            assert source_instance.restore_restorable_state.call_args.args[0].output == "OFF"
            assert source_instance.set_output.call_count == 2
            run_data = json.loads(result.run_json_path.read_text(encoding="utf-8"))
            assert run_data["error"]["safety_gate"]["post_restore"]["status"] == "ok"
        finally:
            patch.stopall()
