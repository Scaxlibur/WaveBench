"""Offline report rendering helpers."""
